"""Render the two report capacity figures from completed records."""
import argparse
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path.cwd()/'tmp/concise-matplotlib-cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter, NullLocator
plt.rcParams.update({'font.size':13,'xtick.labelsize':12,'ytick.labelsize':12})


def plot(root):
    root=Path(root)
    report=json.loads((root/'results/report-data.json').read_text())
    paired=report['v3_followup']
    fig,axes=plt.subplots(1,2,figsize=(10,3.8))
    for policy,color,label in [('original','#2376b8','Original parent fitting'),('classification_refit','#cc3340','Revised parent fitting')]:
        rows=sorted([r for r in paired if r['policy']==policy and r['seed']==409],key=lambda r:r['depth_limit'])
        assert rows and len({r['depth_limit'] for r in rows})==len(rows)
        for ax,split,title in zip(axes,['train','test'],['Training fit','Generalization on reused test set']):
            ax.plot([r['depth_limit'] for r in rows],[100*(1-r[split]['accuracy']) for r in rows],color=color,marker='o',markersize=3,label=label)
            ax.set_xlabel('Allowed tree depth (root = 0)',fontsize=13);ax.set_ylabel('Error (%)',fontsize=13)
            ax.set_title(title,fontsize=14);ax.grid(alpha=.2);ax.legend(fontsize=10)
    axes[0].set_ylim(bottom=0)
    axes[0].axvline(11,color='#538a5e',ls=':',alpha=.7)
    fig.tight_layout();fig.savefig(root/'figures/parent-refit.png',dpi=185,bbox_inches='tight');plt.close(fig)
    data=report['noise_study']
    for budget,records,repeated in [(400,data['records'],False),(1200,data['followup']['records'],True)]:
        fig,axes=plt.subplots(2,2,figsize=(12,7),gridspec_kw={'height_ratios':[2,1]})
        for col,(ds,label) in enumerate([('cifar10','CIFAR-10'),('cats_vs_dogs','Cats vs Dogs')]):
            all_x=[]
            for rate,color in [(0.,'#2376b8'),(.15,'#cc3340')]:
                rows=[r for r in records if r['dataset']==ds and r['noise']['requested_fraction']==rate and (repeated or r['seed']==409)]
                widths=sorted({r['width'] for r in rows})
                groups=[[r for r in rows if r['width']==w] for w in widths]
                assert all(len(g)==(3 if repeated else 1) for g in groups)
                x=[g[0]['feature_parameters']+g[0]['size']['parameters'] for g in groups]
                all_x.extend(x)
                def values(split):
                    raw=[[100*(1-r[split]['accuracy']) for r in g] for g in groups]
                    return [np.mean(v) for v in raw],[np.std(v,ddof=1)/np.sqrt(len(v)) if len(v)>1 else 0 for v in raw]
                for split,marker,linestyle in [('validation','o','-'),('test','s','--')]:
                    m,e=values(split)
                    axes[0,col].errorbar(x,m,yerr=e,marker=marker,ls=linestyle,color=color,alpha=1 if split=='validation' else .75,
                        capsize=3 if repeated else 0,label=f'{rate:.0%} noise / {split}')
                m,e=values('train')
                axes[1,col].errorbar(x,m,yerr=e,marker='o',color=color,capsize=3 if repeated else 0,label=f'{rate:.0%} noise')
                zero=next((i for i,g in enumerate(groups) if all(r['train']['errors']==0 for r in g)),None)
                if zero is not None:
                    for row in [0,1]:axes[row,col].axvline(x[zero],color=color,ls=':',alpha=.5)
            axes[0,col].set_title(label+(' | double-descent-like profile' if budget==400 and ds=='cifar10' else ' | held-out error'),fontsize=14)
            axes[1,col].set_title('Training error: locating interpolation',fontsize=13)
            axes[1,col].set_ylim(bottom=0)
            if all(r['train']['errors']==0 for r in records if r['dataset']==ds):
                axes[1,col].set_ylim(0,1)
            for row in [0,1]:
                ax=axes[row,col];ax.set_xscale('log');ax.set_ylabel('Error (%)',fontsize=14)
                ax.xaxis.set_major_locator(FixedLocator(np.geomspace(min(all_x),max(all_x),3)))
                ax.xaxis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value/1e6:.2f}M'))
                ax.xaxis.set_minor_locator(NullLocator())
                ax.xaxis.set_minor_formatter(NullFormatter())
                ax.grid(alpha=.22);ax.legend(fontsize=12,loc='best')
            axes[1,col].set_xlabel('Allocated parameters (M = million; CNN once)',fontsize=12)
        fig.suptitle(f'{budget:,} epochs per learned node | '+('three-seed means +/- standard error' if repeated else 'primary seed 409'),fontsize=16)
        fig.tight_layout();fig.savefig(root/'figures'/f'capacity-{budget}.png',dpi=185,bbox_inches='tight');plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);plot(p.parse_args().root)
