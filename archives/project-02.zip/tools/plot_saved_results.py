"""Replot representative capacity studies from saved data, without training."""
import argparse
import json
import os
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(root/'tmp/matplotlib-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

data=json.loads((root/'output/double_descent_audit/audit-snapshot.json').read_text())
fig,axes=plt.subplots(4,2,figsize=(13,15),layout='constrained')
for col,ds in enumerate(['cifar10','cats_vs_dogs']):
    v1=sorted([r for r in data['v1'][ds]['models'] if r['name'].startswith('sweep-long-') and r['config']['seed']==409],key=lambda r:r['config']['width'])
    v2=sorted([r for r in data['v2']['tree-budget-v2'] if r['dataset']==ds and r['name'].startswith('capacity-')],key=lambda r:r['config']['width'])
    v3=sorted([r for r in data['v3'][ds] if r['seed']==409 and r['width']==256],key=lambda r:r['depth_limit'])
    v4=sorted([r for r in data['v4'][ds] if r['seed']==409 and r['experiment']=='primary'],key=lambda r:r['width'])
    for row,(title,records,key) in enumerate([('V1 long',v1,'width'),('V2 fixed root',v2,'width'),('V3 width256',v3,'depth'),('V4 primary',v4,'width')]):
        ax=axes[row,col]
        x=[r['depth_limit'] if key=='depth' else r.get('width',r.get('config',{}).get('width')) for r in records]
        for split,color in [('train','#24847d'),('validation','#d38225'),('test','#315d9f')]:
            if all(r.get(split) for r in records):
                ax.plot(x,[100*(1-r[split]['accuracy']) for r in records],'o-',label=split,color=color)
        if key=='width':ax.set_xscale('log',base=2)
        ax.set_title(title+' / '+ds);ax.set_xlabel('Maximum depth' if key=='depth' else 'Hidden width')
        ax.set_ylabel('Classification error (%)');ax.grid(alpha=.2);ax.legend()
path=args.output or root/'figures/reproduced-capacity.png'
path.parent.mkdir(parents=True,exist_ok=True)
fig.savefig(path,dpi=180)
print(path)
