"""Verify all upload files and every ZIP entry without training or dependencies."""
import hashlib
import json
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

root=Path(__file__).resolve().parents[1]
index=json.loads((root/'SUBMISSION_INDEX.json').read_text())
seen=set()
for item in index['upload_files']:
    path=root/item['path']
    assert path.stat().st_size==item['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'], item['path']
for part in index['archives']:
    with ZipFile(root/part['file']) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={v['path'] for v in part['entries']}
        for item in part['entries']:
            name=PurePosixPath(item['path'])
            assert not name.is_absolute() and '..' not in name.parts
            assert (root/name).resolve().is_relative_to(root.resolve())
            assert name.as_posix() not in seen;seen.add(name.as_posix())
            raw=z.read(name.as_posix())
            assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
print('Verified all upload hashes and',len(seen),'unique archived files. No training was run.')
