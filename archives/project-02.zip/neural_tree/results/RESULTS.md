# Completed experimental results

Both datasets meet the designated training-fit target. Test candidates were locked before held-out evaluation; no model is selected here using test accuracy.

| Dataset | Selected training accuracy | Validation accuracy | Test accuracy | Training errors |
|---|---:|---:|---:|---:|
| cifar10 | 99.9933% | 80.48% | 80.02% | 3 / 45000 |
| cats_vs_dogs | 100.0000% | 90.54% | 89.94% | 0 / 18608 |

## Conclusions

No clear model-capacity double descent was observed in either dataset in the tested range. CIFAR validation error generally falls with capacity; Cats vs Dogs shows small, irregular fluctuations. This is evidence about these experiments, not a claim that double descent cannot occur.

Epoch histories show that very low training error can coexist with rising held-out BCE. Confidence on incorrectly classified held-out examples can worsen even when classification error changes little. Binary root-only trajectories must not be interpreted as global CIFAR multiclass trajectories.

## cifar10

The selected tree has 24 active nodes. Pruning leaves 10 roots, reduces total parameters by 23.94%, and preserves the selected validation accuracy in these measurements.

Smallest tested active model retaining at least 99.5% training fit: `sweep-long-w16-s409`. Smallest within the original validation tolerance: `sweep-long-w16-s409`. These searches use train/validation records only and do not change the predeclared selected model.

Narrower nodes can require more correction nodes: reducing width is not a guarantee of a smaller or faster complete classifier. The shared CNN is counted once and dominates the most compact models.

The airplane root activates on all 4,500 airplane training images and seven non-airplanes. Its strongest displayed responses are aircraft against sky or runway backgrounds. Sensitivity appears in both aircraft and surrounding regions. Context use is plausible on these examples but is not an established dataset-wide causal rule.

The airplane negative-correction child fits seven positive targets among 4,507 assigned examples with zero task errors. It nevertheless activates on 6.29% of the entire training set, with ships the largest class. Its strongest displayed responses are a bird and a dog, while the pictured assigned positive target is a cat. Correcting errors does not necessarily produce a simple semantic class detector.

The selected depth-two nodes fit only 31, 81, and 103 assigned examples but activate on about 58.09%, 48.71%, and 42.36% of the full training set. These are different populations. Don't-care masks leave off-task responses unconstrained; those activations do not establish that the corresponding examples were errors. Interpret them together with their parent score and correction sign.

The cat tree's displayed depth-two node responds strongly to two automobiles although the pictured assigned positive task target is a cat. Grad-CAM on the strongest automobile emphasizes a lower wheel/body region, suggesting a local visual cue on that image rather than a universal automobile concept.

The last feature's theoretical receptive field is 36 by 36 pixels, larger than a 32 by 32 CIFAR image. The displayed Grad-CAM is coarse and interpolated; it must not be treated as pixel-precise localization. More images and perturbations are needed to infer stable semantic roles.

## cats_vs_dogs

The selected tree has 6 active nodes. Pruning leaves one root, reduces total parameters by 12.35%, and preserves the selected validation accuracy in these measurements.

Smallest tested active model retaining at least 99.5% training fit: `sweep-long-w8-s409`. Smallest within the original validation tolerance: `sweep-long-w8-s409`. These searches use train/validation records only and do not change the predeclared selected model.

Narrower nodes can require more correction nodes: reducing width is not a guarantee of a smaller or faster complete classifier. The shared CNN is counted once and dominates the most compact models.

The corrected dog root activates on all 9,283 dog training images and no cat training images. The two strongest displayed base-score responses are dogs photographed behind chain-link fencing. Grad-CAM highlights distributed regions on the dog and fence; the largest displayed occlusion effect is near the head/upper-body region. These examples raise a possible background-texture hypothesis, but do not show that fencing alone drives classification across the dataset.

The positive-correction child root.A has four positive targets among 9,329 assigned examples and fits its assigned task without errors. It activates on 58 dogs and no cats over the complete training split. Strong examples are a small puppy being held and a seated spotted dog. The puppy's Grad-CAM emphasizes the muzzle and some surrounding regions, while occlusion also shows sensitivity outside the face. This is consistent with correcting unusual appearances, but does not establish a universal puppy or face detector.

The depth-two root.A.B node is trained on 73 examples, including 69 positive correction targets, yet activates on 87.13% of all training images. Its depth-three child root.A.B.A fits only six examples with two positives, but activates on 45.50% of the full training set. Both have strongly responding caged-cat examples. Their maps emphasize cage/background regions above the cat, and masking those regions reduces the base score. Background sensitivity is visible on these examples, while the broad activations reflect off-task behavior left unconstrained by the masks.

The depth-two root.B.B node fits ten assigned examples, seven positive. Across the full training set it activates on 7,739 cats and 1,950 dogs. Its strongest displayed example is a dark cat held against a red shirt: Grad-CAM and occlusion agree on sensitivity near the cat's eyes and face. Its pictured assigned positive target is nevertheless a dog. Its correction role is defined by its parent task and sign, rather than a simple cat/dog semantic label.

The reviewed tasks become very small at greater depth: six and ten examples compared with 9,329 for the shallow positive-correction child. Their zero assigned-task errors support correction of isolated training cases, while their broad full-dataset activations give no evidence of stable semantic generalization. The corrected root's 100% training fit and 89.94% test accuracy demonstrate a remaining generalization gap.

For 128 by 128 images, a final spatial CNN feature has a theoretical 36 by 36 receptive field. Global pooling exposes the node to the entire image. The coarse Grad-CAM interpolation and 4 by 4 occlusion grid are empirical sensitivity tools, not pixel-precise localization or proofs of causal semantic concepts.

## Limitations

Only selected widths have three seeds. Inactive allocated correction positions do not contribute to inference; active topology changes as error-driven growth responds to capacity. Remaining optimization flags limit strong capacity claims. Timing measurements exclude disk reads and resizing. Attribution maps indicate empirical sensitivity, not proven semantic concepts.

## Submission status

Scientific measurements and interpretations are complete. The private GitHub URL and instructor-access verification must be added after repository creation.
