# Dense validation-only capacity study

Exploratory validation-only extension. Fixed frozen CNN, splits, optimizer and epoch budget. Reuse only exact matching runs; retain every result. No new test evaluation or change to selected models.

Widths: [1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]. Base networks: 300 epochs; corrections: 150. Frozen original CNN; depth-two allocation, seven positions per binary tree.

Matching original long-sweep records are reused with exact configuration/feature identity and provenance. New widths start from scratch with epoch-boundary resume. Measured points are connected; diamonds and bars show repeated-seed means and sample standard deviations. First primary zero error is marked. No spline interpolation or new test evaluation.

## cats_vs_dogs

complete

No clear double-descent pattern was found under this predeclared qualitative criterion.

Completed primary widths: [1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]. Primary zero-error index: 4.

Models with remaining optimization flags: 19.

Qualitative criterion, not a significance test. Selected widths have repeated seeds; active topology varies; remaining optimization flags limit capacity claims. This is exploratory validation evidence after prior test results were viewed.

## cifar10

complete

No clear double-descent pattern was found under this predeclared qualitative criterion.

Completed primary widths: [1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]. Primary zero-error index: 6.

Models with remaining optimization flags: 10.

Qualitative criterion, not a significance test. Selected widths have repeated seeds; active topology varies; remaining optimization flags limit capacity claims. This is exploratory validation evidence after prior test results were viewed.

The qualitative change threshold is max(0.5 percentage points, twice the relevant standard error). It is a screening rule, not a significance test. If width one already interpolates, a separately declared weaker-feature study would be needed to sample underfitting. Width and parameter-count versions of each plot are supplied; allocated/active size is in the table. Original selected models and PDF remain unchanged.
