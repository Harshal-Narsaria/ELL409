# ELL409: Neural Error-Correction Trees

This project implements the upward error-correction construction in Jayadeva's **A Tree Type Neural Network**, replacing each base neuron with a small neural network. It is **not a left/right decision-routing tree**.

The assignment studies CIFAR-10 and Cats vs Dogs, near-perfect training fit, possible double descent, node responses, and model size. Results are saved as measurements; the report generator never invents missing results.

The complete study is finished: 31 locked tree configurations on each dataset, capacity and epoch studies, node visualizations, compression, and held-out test evaluation. See [reviewed results](results/RESULTS.md), the report in `report/` (upload folder) or `output/` (original workspace), and [GitHub upload instructions](docs/UPLOAD_TO_GITHUB.md).

A simpler professor-facing copy is in [github-upload/ELL409-professor-view](github-upload/ELL409-professor-view/README.md), with runnable code, the report, key plots, all-model comparisons, and explicit interpolation/epoch comparisons visible. Its `supplementary/full-records.zip` preserves every original upload-package file. The original full upload folder remains intact. Reproduce this organization with `python scripts/make-review-folder.py`; use `--refresh` only for an unchanged generated copy. The transfer archive is `dist/ELL409-professor-view.zip`.

An additional dense train/validation capacity study is configured in `configs/dense-study.json`; see [its protocol and background runner](docs/DENSE_STUDY.md). It preserves the original selected models and test results. Live measurements and graphs appear in `results/dense-capacity-2026-10-08/`; completed artifacts are packaged separately as `ELL409-professor-view-dense`. Those exploratory results are pending until that study's progress record says `complete`.

| Selected model | Training accuracy | Validation accuracy | Test accuracy |
|---|---:|---:|---:|
| CIFAR-10 correction trees | 99.9933% (3 errors / 45,000) | 80.48% | 80.02% |
| Cats vs Dogs correction tree | 100% (0 / 18,608) | 90.5417% | 89.9398% |

No clear capacity double descent was observed under the studied settings. All 22 verification tests passed. Full image-to-prediction checks matched cached-feature predictions on every training and validation image. Test results were locked before review and were not used for further tuning. The PDF's only pending submission field is the actual private repository URL.

## Start on this computer

Open a terminal in this folder. The project environment is currently in the parent folder:

```powershell
..\.venv\Scripts\python.exe -m ell409_tree doctor
..\.venv\Scripts\python.exe -m pytest -q
```

Prepare and run CIFAR-10:

```powershell
..\.venv\Scripts\python.exe -m ell409_tree prepare cifar10
..\.venv\Scripts\python.exe -m ell409_tree run --manifest data/cifar10/manifest.json --config configs/cifar10.json --run-dir runs/cifar10
```

Prepare and run Cats vs Dogs:

```powershell
# Only needed on this Windows machine: the TF packages use a short dependency path.
$env:ELL409_TF_LIBRARY = 'C:\Users\narsa\AppData\Local\Temp\ell409-tree-tensorflow'
..\.venv\Scripts\python.exe -m ell409_tree prepare cats_vs_dogs
..\.venv\Scripts\python.exe -m ell409_tree run --manifest data/cats_vs_dogs/manifest.json --config configs/cats_vs_dogs.json --run-dir runs/cats_vs_dogs
```

The temporary TensorFlow dependency path can be removed by Windows cleanup. If preparation is needed again, reinstall the two packages with `--no-deps --target` into a short path and set `ELL409_TF_LIBRARY`. Windows TFDS preparation also uses a short temporary cache path (override with `ELL409_TFDS_DIR`) to avoid long download-cache filenames. The exported images and manifest remain in this project. Ordinary Linux/Colab/Kaggle installations do not need these workarounds. TensorFlow is used for official data preparation only, not model training.

For another computer or a downloaded archive, use Python 3.10+ (3.12 recommended), create a virtual environment, install a suitable [GPU PyTorch build](https://pytorch.org/get-started/locally/), then install this project:

```text
python -m pip install -e ".[test,cats]"
python -m ell409_tree doctor
```

On Windows, use a short environment path if TensorFlow installation exceeds Windows path limits. Run `doctor` before long experiments: a CPU PyTorch installation will not use the RTX 2050.

## Safe restart and experiment stages

Running exactly the same command again resumes checkpoints. Epoch journals restore optimizer and random-generator state; completed recursive subtrees and experiments are reused. Do not change the config or manifest inside an existing run directory. Use a new run directory for a new experiment.

Long studies can run one stage at a time:

```text
python -m ell409_tree run ... --stage cnn
python -m ell409_tree run ... --stage features
python -m ell409_tree run ... --stage trees
python -m ell409_tree run ... --stage sweep
python -m ell409_tree run ... --stage compress
python -m ell409_tree visualize --manifest data/cifar10/manifest.json --run-dir runs/cifar10
```

Replace `...` with the same `--manifest`, `--config`, and `--run-dir` arguments each time. `--stage all` is the default and runs these stages in order. No test accuracy is calculated until explicit finalization. Feature extraction may read test images but never fits normalization or weights on them.

After validation comparisons and convergence checks are complete, declare and evaluate all candidates:

```text
python -m ell409_tree finalize --manifest data/cifar10/manifest.json --config configs/cifar10.json --run-dir runs/cifar10
python -m ell409_tree finalize --manifest data/cats_vs_dogs/manifest.json --config configs/cats_vs_dogs.json --run-dir runs/cats_vs_dogs
```

`--finalize` on an `all` run performs this automatically at the end. A test-declaration file locks candidate names and configuration. Existing test measurements are reused rather than recomputed. After finalization, do not add candidates to that directory or use its test results to tune hyperparameters.

## Architecture and growth

- Shared CNN: two 3x3 convolutions per block, channels 32/64/128, ReLU, pooling, global average pooling, 128 features.
- Common image and feature normalization: fitted using training examples only.
- Node: 128 -> width -> 1, ReLU, binary cross-entropy.
- Parent score: `base(features) + alpha * child_A - beta * child_B + offset`; alpha/beta remain nonnegative.
- Children return hard binary decisions, recursively corrected by their own children.
- The base score is frozen during correction fitting. This is an explicit neural extension of the PDF's linear parent refit.
- After projected-gradient fitting, an exact three-variable signed margin-one refit is attempted. For each child-output/label combination, only the worst base score is needed: at most eight constraints certify all training margins. Feasible candidates are accepted only if training error/loss improves. Infeasibility concerns the fixed-score margin-one problem; a smaller-margin correct refit may still exist, so it does not prove global impossibility.
- Table-II masks exclude the two don't-care cases. Class-balanced BCE handles sparse positive correction targets. Best weights are selected by unweighted training-error count, then unweighted BCE.
- Defaults: depth 4, at most 31 nodes per binary tree, node width 64. Root depth is 0.
- Cats vs Dogs: one binary tree. CIFAR-10: ten one-versus-rest trees with argmax root-score prediction. Final multiclass accuracy is never replaced by the average binary accuracy.
- If 99.5% training accuracy is not reached, the pipeline tries width 128, width 256, and then depth 5 / 63 nodes, retaining the best measured fit.

The PDF has inconsistencies: positive slack need not mean misclassification, and zero slack is not an error condition. Child tasks use actual predictions and labels. Contradictory labels or indistinguishable frozen features can prevent perfect fitting.

## Data and evaluation

CIFAR-10 uses the official 50,000 training / 10,000 test images; the training set is split approximately 90/10 into training and validation with duplicate groups preserved. Exact train/test duplicates are excluded from training. Consequently, actual counts may differ slightly from 45,000/5,000; the manifest records every retained example and exclusion.

Cats vs Dogs uses `tensorflow_datasets`' official `cats_vs_dogs:4.0.1` generator, including corrupt-image filtering, followed by lossless PNG export at the required 128x128 resolution and an approximately stratified 80/10/10 grouped split. Resizing once at export uses exactly the same RGB/bilinear operation as the training loader. Original decoded-pixel and resized-input hashes are recorded. On Windows, only the generator's archive-path normalization is replaced locally; JPEG recoding and corrupt-image filtering remain official.

The live audit found one contradictory exact duplicate: the red **Adopted** placeholder appears with both cat and dog labels (`cats-04409`, `cats-08701`). Both are excluded from modeling and fully recorded in `duplicate-audit.json` and manifest provenance; neither label is changed, and the original source export remains intact. Thus TFDS exports 23,262 valid images and modeling uses 23,260. All other same-label duplicate groups are retained together. The generic splitting function still rejects unhandled contradictory groups.

The full dataset manifest contains source/version, image IDs, decoded-pixel hashes, split membership, and training-only normalization. Main runs have no augmentation, dropout, label smoothing, or weight decay. Smoke data is explicitly labeled synthetic and never counts toward assignment completion.

## Experiments and interpretation

`all` runs CNN and root-only baselines, adaptive correction trees, a fixed-depth capacity sweep, selected seed repeats, pruning, narrower trees, figures, and node visualizations.

The sweep uses widths 8/16/32/64/128/256/512 and a fixed depth-2 allocation of seven nodes per binary tree. Unneeded positions are inactive. Both allocated and active sizes are reported, because a nominal parameter count can be misleading if positions do not participate. There is a separate early-trunk sweep if the smallest model already interpolates. Report this distinction when interpreting capacity curves.

Run convergence diagnostics before attributing a nonmonotonic curve to double descent. If node loss drops more than 1% over the last up to 20 epochs while errors remain, the pipeline repeats the entire sweep with a common 300-epoch budget (`max_sweep_epochs` overrides this). Remaining flags are reported as limitations rather than convergence guarantees. Local node epoch histories are retained; CNN epoch plots are **not** described as tree epoch-wise double descent.

`python -m ell409_tree epoch-history --run-dir runs/cifar10 --device cpu` records actual uninterrupted 300-epoch trajectories for root-only widths 8/64/512, with held-out errors, BCE, positive recall, and negative accuracy. CIFAR uses cat versus the other nine classes; Cats vs Dogs uses dog versus cat. These are representative binary node models before correction children, not final multiclass tree trajectories. The finite CPU companion `scripts/epoch-study.py` completed all three 300-epoch trajectories for each dataset; its historical progress is in `runs/epoch-study.log`. It does not inspect test labels or modify the final test candidate list.

Pruning's 0.5-percentage-point tolerance is measured cumulatively against the original validation accuracy. Width-32/16 trees use the selected model's depth/node budget and are re-grown; their realized topology can change. The deployment includes CNN weights and preprocessing statistics and excludes training journals/task records. Cached-feature timing and image-to-prediction timing are reported separately; the latter excludes disk reads and resizing.

```text
python -m ell409_tree predict --deployment runs/cifar10/adaptive-w64/deployment.pt --image example.png
```

Grad-CAM targets a continuous base score, with gradients enabled through the frozen CNN. Occlusion replaces image regions with the training mean. Strong activations, correction targets, and class-composition histograms are shown. Maps are empirical sensitivities, not proof of semantic concepts. The last spatial features have theoretical receptive field 36x36; global pooling gives nodes access to the whole image.

## Reports, sharing, and private GitHub

```text
python -m ell409_tree report --runs-root runs --output output/ELL409_Neural_Tree_Report.pdf
python -m ell409_tree package --output dist/ell409-neural-tree.zip
```

The first command makes an honest **draft** from whatever evidence exists. For a final report, both full dataset workflows must be complete, the fitting target met, and the real repository URL supplied:

```text
python -m ell409_tree report --runs-root runs --output output/ELL409_Neural_Tree_Report.pdf --repository-url https://github.com/YOUR_ACCOUNT/YOUR_PRIVATE_REPO --final
```

Create a **private** repository, push this project, and arrange grader access according to course instructions. Repository privacy and access must be checked on GitHub; a URL alone does not verify them. No external repository is fabricated. Data, checkpoints, and virtual environments are ignored. Small report/figure artifacts can be shared separately or force-added deliberately when ready.

Both finite background runners completed successfully. No training remains scheduled. Their logs are retained locally in `runs/study-queue.log` and `runs/epoch-study.log`. Do not restart a finished study or modify its locked candidates based on test results.

The standalone upload folder includes `evidence/` with measured histories, split manifests, six deployment models, and the complete report. It excludes the image datasets and training caches. To regenerate plots and audit tables from its saved evidence:

```text
python -m ell409_tree figures --runs-root evidence --output-dir results
```

The original workspace keeps the full training checkpoints and feature caches in `runs/`; those can resume unfinished new experiments. Uploading the folder does not run any process automatically.

Read [the cloud guide](docs/CLOUD.md) for the Colab/Kaggle notebook and checkpoint transfer. Read [the study checklist](docs/STUDY_CHECKLIST.md) before final submission.
