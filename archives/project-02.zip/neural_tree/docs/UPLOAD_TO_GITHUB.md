# Upload and submit

All scientific work is complete. The actual private GitHub repository URL must still be added to the report after you create the repository.

1. Create a **private** GitHub repository. Leave it empty initially, without generating a second README.
2. Add the **contents** of `ELL409-neural-tree` as the repository root. The root should contain `README.md`, `pyproject.toml`, `ell409_tree/`, `report/`, `evidence/`, and `models/`. GitHub Desktop's “Add local repository” / “Create repository” workflow is convenient; you can also upload the folder contents through GitHub's website in batches. The ZIP is a transport copy: extract it before adding the files.
3. Commit and push the files. Check that the six `.pt` files in `models/` appear on GitHub: the included ignore rules explicitly permit these deployment models. Datasets and environments are omitted.
4. Arrange instructor/grader access according to the course instructions. Verify privacy and access in GitHub's settings.
5. Add your actual repository URL to the PDF. From this folder, after installing the project, run the command below, substituting your real URL. You can also send the URL to this chat for the PDF update.

```text
python -m ell409_tree report --runs-root evidence --output report/ELL409_Neural_Tree_Report.pdf --repository-url https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY --final
```

6. Push the updated PDF and submit it through the course's required submission channel. Follow any course requirements for your name, entry number, deadline, and filename.

## Included evidence

- `report/`: complete report, currently marked repository-link pending.
- `ell409_tree/`, `configs/`, `scripts/`, `tests/`, `notebooks/`: runnable implementation, recorded dependencies, reproducible experiments, and cloud support.
- `evidence/`: histories and locked evaluation records for all 62 configurations, both CNN baselines, node figures, interpretation notes, and three 300-epoch binary-root trajectories per dataset.
- `results/`: audit tables, reviewed conclusions, confusion and compression figures, repeated latency measurements, compact-model provenance, and complete training/validation image-path verification.
- `splits/`: exact split manifests, normalization, duplicate audits, and dataset provenance. Download/preparation instructions are in the README; images themselves are omitted.
- `models/`: selected correction tree, validation-pruned tree, and smallest tested near-perfect compact model for each dataset. Each file includes the CNN and preprocessing statistics needed for inference.
- `UPLOAD_MANIFEST.json`: file sizes and SHA-256 hashes for the original prepared package. Later edits require a new manifest if you want a fresh integrity record.

The smaller compact models were identified by training/validation measurements. Their test metrics are inherited from the unchanged predeclared source models; no additional test evaluation was performed to select them.

## Reproduce without retraining

Use Python 3.12 and install a suitable PyTorch build, then `python -m pip install -e ".[test]"`. The recorded lock file documents the actual Windows training environment; another platform may need a different compatible GPU build.

```text
python -m pytest -q
python -m ell409_tree figures --runs-root evidence --output-dir results
python -m ell409_tree predict --deployment models/cifar10/adaptive-w64.pt --image YOUR_IMAGE.png
python -m ell409_tree predict --deployment models/cats_vs_dogs/adaptive-w64.pt --image YOUR_IMAGE.jpg
```

Plot regeneration uses saved measurements. Node image maps are included; recreating them from scratch requires dataset preparation and the full training workflow. Optimizer checkpoints and feature caches remain in the original local workspace and are excluded from this upload folder. The README describes how to reproduce the full study in new run directories.

The background study has finished. This folder does not run training automatically.
