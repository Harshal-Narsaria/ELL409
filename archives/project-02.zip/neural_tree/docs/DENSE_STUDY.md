# Additional dense capacity study

Exploratory extension using the original frozen CNN features/splits, 300 base epochs, 150 correction epochs, and depth-two allocation (seven positions per binary tree). Train/validation only; no new test evaluation or change to selected models. All measurements are retained.

Widths: 1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512. Primary seed 409; seeds 410/411 at CIFAR widths 16/24/32/48 and Cats widths 8/12/16/24. Matching original long-sweep repetitions are also retained. Reuse requires matching feature identity, manifest, and complete configuration.

First reproduce the original CNN/features with the main dataset configurations. If compatible original long-sweep measurements are unavailable, the dense runner trains them too. The frozen study definition includes a validation-tensor hash; changing a protocol requires a new study directory.

```text
python -m ell409_tree dense-study --source-root runs --study-dir runs/dense-capacity-2026-10-08 --output-dir results/dense-capacity-2026-10-08 --config configs/dense-study.json --device cuda
```

On this Windows checkout:

```powershell
./scripts/run-dense-study.ps1 -PrepareOnly
./scripts/run-dense-study.ps1 -Background
```

The runner is finite and automatic. Keep Windows awake and connected to power. Rerun the same command after interruption to restore completed node epochs, optimizer/RNG states and recursive subtrees. A process lock prevents two active writers. Progress is in `runs/dense-capacity-2026-10-08/progress.json`; logs are `stdout.log` and `stderr.log`. Tables and graphs refresh after each completed configuration. Pending widths/repetitions are labeled partial, not interpolated.

Figures show training/validation error and loss against width or allocated parameters. Seed 409 is the solid curve; repeated-seed means and sample SD bars are overlaid. The first primary zero-training-error point is marked. The qualitative double-descent criterion is not a significance test. Remaining convergence flags and changing active topology limit conclusions. If width one already interpolates, a separately declared weaker-feature study would be needed to sample underfitting.

On completion, original test records and report hashes are verified, new scientific records are archived, and `github-upload/ELL409-professor-view-dense` plus its ZIP are created. The existing PDF remains unchanged; the new curves are an explicitly labeled validation addendum. Image datasets, feature caches, and optimizer journals remain local. Prior test results have already been viewed, so these findings are exploratory validation evidence rather than independent test-confirmed improvements.
