# Initial measured results: 4 October 2026

These are intermediate measurements, before the locked test evaluation. They do not establish double descent or complete the assignment.

| CIFAR-10 model | Full training accuracy | Validation accuracy | Active nodes |
|---|---:|---:|---:|
| Best shared CNN checkpoint | 98.5644% | 79.54% | Conventional head |
| Width-64 roots only | 99.9800% | 80.44% | 10 |
| Width-64 correction trees | 99.9933% | 80.48% | 24 |

The correction model makes three errors on 45,000 training examples. The roots-only model already meets the 99.5% fitting criterion; the correction improvement is 0.0133 percentage points in training and 0.04 percentage points in validation. A single-seed difference this small does not establish a generalization benefit.

## Reading the initial node figures

The airplane root activates on all 4,500 airplane training images and seven non-airplanes. Its strongest examples are airplanes against sky or runway backgrounds. The displayed Grad-CAM and occlusion maps distribute sensitivity over both aircraft and surrounding regions. Background/context use is a plausible interpretation, not an established causal rule across the dataset.

The airplane root's negative-correction child has seven positive task targets among 4,507 assigned examples and fits that task without errors. Across the whole training set, however, it activates on 6.29% of examples, most often ships. The examples producing its largest base scores are a bird and a dog; the pictured assigned correction target is a cat. A correction task does not necessarily produce a clean semantic class detector.

The selected depth-two nodes fit only 31, 81, and 103 assigned examples, yet activate on approximately 58.09%, 48.71%, and 42.36% of the entire training set. These are different populations. The don't-care masks constrain each child only on its assigned task; broad off-task responses do not show that those images were errors or required correction. Each output must be interpreted together with the parent score and correction sign.

In the cat tree's depth-two negative-correction node, the strongest shown responses are automobiles, while the pictured positive task target is a cat. Grad-CAM on the strongest automobile concentrates near a lower wheel/body region. This suggests a possible local visual cue on that example, but gives no basis for calling this a universal automobile detector.

CNN maps are coarse and image-dependent. The last spatial feature's theoretical receptive field is 36 by 36 pixels, already larger than a 32 by 32 CIFAR image. Grad-CAM interpolation must not be treated as pixel-precise localization. More examples and perturbations are needed before assigning stable semantic descriptions.

## Later completion

This file preserves the 4 October intermediate snapshot. Both full studies have since completed, including repeated seeds, compression, node interpretation, and locked test evaluation. See [the reviewed final results](../results/RESULTS.md) and the complete PDF report for the current conclusions.
