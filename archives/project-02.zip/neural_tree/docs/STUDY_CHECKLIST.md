# One-week study checklist

## Day 1: implementation and data
- Run tests and the clearly labeled synthetic smoke workflow.
- Verify CUDA, dataset provenance, duplicate audit, and disjoint split hashes.
- Create the private repository and confirm grader-access instructions.
- Preserve configs and inspect resume on a small run.

## Days 2-3: fitting
- Complete both CNNs and frozen feature caches.
- Inspect actual per-epoch times before committing to the full matrix.
- Complete conventional CNN, root-only, and adaptive correction-tree comparisons.
- Verify final full-split train accuracy, not minibatch or local-node accuracy.
- If below 99.5%, inspect remaining cases, optimization, and feature collisions before increasing size.

## Days 4-5: capacity and interpretation
- Complete the fixed allocation width sweep on each dataset.
- Repeat selected widths across three seeds.
- Check whether near-threshold runs converged. Extend the common epoch budget in a separately named study if needed.
- Inspect node figures, multiple activating images, correction targets, and occlusion responses.
- Explain observations using examples; do not assign semantics from a single heatmap.
- Distinguish no observed double descent from an incomplete experiment.

## Day 6: size and held-out evaluation
- Compare pruning, width-32/16 trees, active and allocated parameters, deployment bytes, and inference timing.
- Lock the test candidate list only after validation exploration is complete.
- Evaluate the final candidates without subsequent test-guided tuning.
- Record both training-fit preservation and validation-accuracy preservation.

## Day 7: submission
- Generate the PDF from saved measurements, replacing draft status only when evidence is complete.
- Add the real private GitHub URL and confirm the instructor can access it.
- Read every PDF page and verify figure captions, dataset counts, limitations, and conclusions.
- Include reproduction commands and precise dataset/library versions.
- Preserve both failed and successful experimental records. Do not present synthetic runs as assignment results.
