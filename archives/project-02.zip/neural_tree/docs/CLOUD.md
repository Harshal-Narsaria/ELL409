# Move the same experiment to Colab or Kaggle

The included `notebooks/cloud_runner.ipynb` is a real notebook wrapper around the same Python package. It is not a second implementation. Keep it private while working on the graded assignment.

## Transfer bundle

Generate `dist/ell409-neural-tree.zip` using the package command. The archive contains code, configs, tests, documentation, and the notebook, but excludes datasets, virtual environments, credentials, and bulky run outputs.

To resume an existing run, transfer its **entire run folder**, the **same manifest**, and data records matching that manifest. Include:

- `cnn-latest.pt`, `cnn-best.pt`, and `cnn-early.pt` if available;
- `features.pt` and `features-early.pt` if available;
- all node base/correction journals and final subtree checkpoints;
- configurations and metric files.

Images can be downloaded again from the official source, but verify the regenerated manifest fingerprint before resume. For maximum assurance, transfer the original manifest and prepared images as well. The feature cache identity includes the actual trunk weights and training-feature values.

## Colab

1. Open the notebook in Colab, save your own copy, and select a GPU under **Runtime -> Change runtime type**.
2. Upload the code archive. If using GitHub instead, access the private repo with notebook secrets; never put a credential in the notebook or output.
3. Extract the project, install its dependencies, and run the notebook's environment check.
4. Mount Drive for persistent checkpoints; use the runtime's local storage for image files and active training files.
5. Restore the same split and run directory, then rerun the same command. Copy an epoch-consistent snapshot back to Drive periodically.
6. When disconnecting, preserve completed checkpoints, metrics, and figures. A notebook file alone does not save trained weights.

The notebook can train directly into Drive for simple persistence, but local training plus snapshot copies usually performs better. The sync helper retries files replaced during atomic checkpoint saves. At worst, an interrupted snapshot resumes from the preceding complete epoch/subtree.

GPU models and availability vary. Consult your actual runtime and [the official FAQ](https://research.google.com/colaboratory/faq.html); no paid subscription is required by this project.

## Kaggle

1. Create a private notebook and select an available GPU under **Settings -> Accelerator**.
2. Attach the code archive and, for resume, prepared data/run files as private dataset inputs or saved notebook outputs.
3. Extract code and copy any resumable run to `/kaggle/working`; attached inputs are read-only.
4. Run the notebook. Save checkpoints and generated artifacts in `/kaggle/working`.
5. Save a Version with outputs and download important checkpoint files before ending a session. A notebook code save is not a substitute for preserving output files.
6. Attach the saved output/version to the next session and resume from the copied run directory.

Check the account's displayed GPU quota and current availability, rather than assuming a fixed allocation. [Official notebook documentation](https://www.kaggle.com/docs/notebooks).

## Consistency

Keep the original effective batch size, optimizer settings, seed, split, and frozen trunk across a comparison. If hardware forces a configuration change, use a new run directory and record the difference. Hardware/software changes can prevent bit-identical results, even when RNG state is restored. Avoid changing a running experiment's code; restart after modifications.
