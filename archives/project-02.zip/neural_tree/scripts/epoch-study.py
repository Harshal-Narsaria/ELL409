"""Finite CPU companion: wait for shared feature caches, record true node epoch traces."""
import os
import subprocess
import sys
import time
from pathlib import Path

project = Path(__file__).resolve().parents[1]
os.chdir(project)
for dataset in ("cifar10", "cats_vs_dogs"):
    while not Path(f"runs/{dataset}/features.pt").exists():
        print(f"Waiting for {dataset} feature cache", flush=True)
        time.sleep(30)
    subprocess.run([sys.executable, "-u", "-m", "ell409_tree", "epoch-history", "--run-dir", f"runs/{dataset}", "--device", "cpu"], check=True)
    subprocess.run([sys.executable, "-m", "ell409_tree", "report", "--runs-root", "runs", "--output", "output/ELL409_Neural_Tree_Report.pdf"], check=True)
