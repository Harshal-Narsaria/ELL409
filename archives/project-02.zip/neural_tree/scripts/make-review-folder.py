"""Create a concise submission view without discarding any original evidence."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import csv
import hashlib
import json
import shutil


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def build(source, output, refresh=False):
    source, output = source.resolve(), output.resolve()
    if source == output or source in output.parents or output in source.parents:
        raise ValueError("Source and output must be separate sibling folders")
    if output.exists() and any(output.iterdir()):
        if not refresh:
            raise FileExistsError("Use an empty output folder, or --refresh for an unchanged generated copy")
        previous = load(output / "UPLOAD_MANIFEST.json")
        expected = {row["path"] for row in previous["files"]} | {"UPLOAD_MANIFEST.json"}
        actual = {p.relative_to(output).as_posix() for p in output.rglob("*") if p.is_file()}
        if actual != expected:
            raise ValueError("Refresh refused: the generated folder has added or missing files")
        for row in previous["files"]:
            if hashlib.sha256((output / row["path"]).read_bytes()).hexdigest() != row["sha256"]:
                raise ValueError("Refresh refused: an existing generated file was edited: " + row["path"])
    output.mkdir(parents=True, exist_ok=True)

    def copy(relative, destination=None):
        src = source / relative
        dest = output / (destination or relative)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)

    for directory in ("ell409_tree", "configs", "tests", "models", "notebooks", "scripts"):
        for path in sorted((source / directory).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                copy(path.relative_to(source))
    # Keep the reversible packaging procedure available in the review copy too.
    shutil.copy2(Path(__file__), output / "scripts" / Path(__file__).name)
    for name in ("pyproject.toml", "requirements-lock.txt", ".gitignore"):
        copy(name)
    copy("report/ELL409_Neural_Tree_Report.pdf")
    copy("docs/CLOUD.md")
    for path in sorted((source / "results").rglob("*")):
        if path.is_file() and path.name != "analysis.json":
            copy(path.relative_to(source))

    # Preserve every file in the original upload package, including all repeated
    # seeds and unsuccessful comparisons. These are compressed, not concealed.
    archive = output / "supplementary" / "full-records.zip"
    archive.parent.mkdir(parents=True, exist_ok=True)
    original = sorted(p for p in source.rglob("*") if p.is_file())
    with ZipFile(archive, "w", ZIP_DEFLATED) as z:
        for path in original:
            z.write(path, path.relative_to(source).as_posix())

    selected = ["roots-only", "adaptive-w64", "pruned", "narrow-w32", "narrow-w16",
                "sweep-w8-s409", "sweep-w128-s409", "sweep-w512-s409"]
    cases, capacities, epoch_cases, cnn_cases = {}, [], [], []
    for dataset in ("cifar10", "cats_vs_dogs"):
        run = source / "evidence" / dataset
        cases[dataset] = {"policy": "Fixed architecture examples plus predeclared initial widths 8, 128 and 512; descriptive, not test-guided model selection.", "models": []}
        for name in selected:
            m = load(run / name / "metrics.json")
            m["test"] = load(run / name / "test-metrics.json")
            cases[dataset]["models"].append(m)
        cases[dataset]["cnn"] = {**load(run / "cnn-baseline.json"), "test": load(run / "cnn-test.json")}
        for tag in ("sweep", "sweep-long"):
            for m in load(run / (tag + ".json")):
                test = load(run / m["name"] / "test-metrics.json")
                capacities.append({"dataset": dataset, "study": tag, "model": m["name"], "width": m["config"]["width"],
                    "base_epochs": m["config"]["node_epochs"], "train_errors": m["train"]["errors"],
                    "train_error_percent": m["train"]["errors"] / m["train"]["examples"] * 100,
                    "validation_error_percent": m["validation"]["errors"] / m["validation"]["examples"] * 100,
                    "test_error_percent": test["errors"] / test["examples"] * 100,
                    "active_parameters": m["size"]["active_parameters"], "allocated_parameters": m["size"]["allocated_parameters"]})
        for width in (8, 64, 512):
            m = load(run / "root-epoch-history" / f"w{width}.json")
            for h in m["history"]:
                if h["epoch"] not in (1, 10, 50, 100, 200, 300):
                    continue
                v = h["validation"]
                epoch_cases.append({"dataset": dataset, "binary_positive_class": m["positive_name"], "width": width,
                    "epoch": h["epoch"], "train_errors": h["errors"], "train_error_percent": h["errors"] / h["examples"] * 100,
                    "validation_error_percent": v["errors"] / v["examples"] * 100, "train_bce": h["loss"],
                    "validation_bce": v["loss"], "validation_positive_recall": v["positive_recall"]})
        for h in load(run / "cnn-history.json"):
            if h["epoch"] in (1, 5, 10, 20, 30):
                cnn_cases.append({"dataset": dataset, "epoch": h["epoch"],
                    **{f"{s}_error_percent": h[s]["errors"] / h[s]["examples"] * 100 for s in ("train", "validation")},
                    **{f"{s}_loss": h[s]["loss"] for s in ("train", "validation")}})
        for name in ("cnn-epochs.png", "sweep.png", "sweep-long.png", "root-epochs-w8.png", "root-epochs-w64.png", "root-epochs-w512.png"):
            copy(f"evidence/{dataset}/figures/{name}", f"figures/{dataset}/{name}")
        nodes = load(run / "node-observations.json")["nodes"]
        # Root, shallow correction, and deepest reviewed correction; all others
        # remain displayed in the PDF and available in the complete archive.
        chosen = [nodes[0], nodes[1], max(nodes[2:], key=lambda n: n["depth"])]
        for n in chosen:
            copy(f"evidence/{dataset}/figures/nodes/{n['figure']}", f"figures/{dataset}/nodes/{n['figure']}")
    write(output / "results" / "featured-cases.json", cases)
    for name, records in (("capacity-comparison.csv", capacities), ("epoch-comparison.csv", epoch_cases), ("cnn-epoch-comparison.csv", cnn_cases)):
        with (output / "results" / name).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0])); writer.writeheader(); writer.writerows(records)
    plot_capacities(output, capacities)
    (output / "README.md").write_text(readme(), encoding="utf-8")
    (output / "docs" / "EXPERIMENT_GUIDE.md").write_text(guide(capacities), encoding="utf-8")
    (output / "supplementary" / "README.md").write_text("# Complete supplementary records\n\n`full-records.zip` preserves every original upload-package file, including all 62 tree configurations, repeats, per-epoch histories, split manifests, and original documentation. No experiment is dropped based on its result.\n\nExtract into `supplementary/full-records/` to restore the original runnable package. Image datasets and optimizer checkpoints were already excluded from that original upload package; preparation instructions and full local training checkpoints remain available as documented.\n", encoding="utf-8")
    manifest = [{"path": p.relative_to(output).as_posix(), "bytes": p.stat().st_size,
                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(output.rglob("*")) if p.is_file() and p.name != "UPLOAD_MANIFEST.json"]
    write(output / "UPLOAD_MANIFEST.json", {"files": manifest, "original_files_preserved_in_archive": len(original),
        "report": "Copied unchanged; actual private GitHub repository URL still pending.", "measurements": "All previously locked; no retraining or new test evaluation."})
    # Integrity checks apply to both visible files and every archived source file.
    with ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == {p.relative_to(source).as_posix() for p in original}
        for p in original:
            assert z.read(p.relative_to(source).as_posix()) == p.read_bytes()
    assert (output / "report/ELL409_Neural_Tree_Report.pdf").read_bytes() == (source / "report/ELL409_Neural_Tree_Report.pdf").read_bytes()
    for row in manifest:
        assert hashlib.sha256((output / row["path"]).read_bytes()).hexdigest() == row["sha256"]
    outer = output.parents[1] / "dist" / "ELL409-professor-view.zip"
    outer.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(outer, "w", ZIP_DEFLATED) as z:
        for p in sorted(output.rglob("*")):
            if p.is_file(): z.write(p, output.name + "/" + p.relative_to(output).as_posix())
    print(json.dumps({"folder": str(output), "visible_files_including_manifest": len(manifest) + 1,
                      "archived_original_files": len(original), "supplementary_zip_bytes": archive.stat().st_size,
                      "download_zip": str(outer), "integrity": "All archived and visible hashes verified"}, indent=2))


def plot_capacities(output, rows):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    for dataset in ("cifar10", "cats_vs_dogs"):
        fig, axes = plt.subplots(2, 2, figsize=(11, 7))
        for i, study in enumerate(("sweep", "sweep-long")):
            records = [r for r in rows if r["dataset"] == dataset and r["study"] == study]
            x = [r["allocated_parameters"] for r in records]
            first = next((r for r in records if r["train_errors"] == 0), None)
            for j, (key, label, color) in enumerate((("train_error_percent", "Training error (%)", "#2166ac"),
                                                   ("validation_error_percent", "Validation error (%)", "#d95f02"))):
                ax = axes[i, j]
                ax.plot(x, [r[key] for r in records], marker="o", color=color)
                for r in records:
                    offset = 22 if dataset == "cats_vs_dogs" and study == "sweep-long" and j == 0 and r["width"] == 16 else 8
                    ax.annotate("w" + str(r["width"]), (r["allocated_parameters"], r[key]), xytext=(0, offset), textcoords="offset points", ha="center", fontsize=8)
                if first:
                    ax.axvline(first["allocated_parameters"], color="gray", linestyle="--", label=f"First zero train error: w{first['width']}")
                    ax.legend(fontsize=8)
                ax.set_xscale("log")
                ticks = [300000, 400000, 600000] if dataset == "cats_vs_dogs" else [400000, 1000000, 2000000, 4000000]
                ax.set_xticks(ticks, [f"{t / 1e6:g}M" for t in ticks])
                ax.set_xticks([], minor=True)
                ax.set_xlabel("Allocated parameters, shared CNN counted once")
                ax.set_ylabel(label); ax.set_title(f"{records[0]['base_epochs']} base epochs - {label}")
                ax.margins(y=.25); ax.grid(alpha=.2)
                if j == 0:
                    peak = max(r[key] for r in records)
                    ax.set_ylim(bottom=-max(peak * .09, .003), top=peak * 1.45 + .025)
                    ax.set_yticks([t for t in ax.get_yticks() if 0 <= t <= ax.get_ylim()[1]])
        fig.suptitle(dataset + ": primary seed 409; separate scales expose small training-error differences")
        fig.tight_layout(rect=(0, .045, 1, .96))
        fig.text(.5, .015, "Descriptive saved measurements. Repeated-seed variability is shown in the original sweep plots; no clear double descent was established.", ha="center", fontsize=8)
        fig.savefig(output / "results" / "figures" / f"{dataset}-interpolation-comparison.png", dpi=170)
        plt.close(fig)


def readme():
    return """# ELL409 Neural Error-Correction Trees

This submission view keeps the runnable code and primary scientific evidence easy to find. Detailed repeated-run records and auxiliary documentation are preserved in one supplementary archive. The complete original submission folder remains intact locally.

## Start reading here

1. [PDF report](report/ELL409_Neural_Tree_Report.pdf): architecture, fitting, double descent, node interpretation, compression, and all locked results.
2. [Experiment guide](docs/EXPERIMENT_GUIDE.md): how the assignment requirements map to the implementation and which plots/cases answer them.
3. [Reviewed results](results/RESULTS.md) and [all 62 model comparisons](results/model-comparison.csv).
4. [Capacity cases](results/capacity-comparison.csv), [CNN epoch cases](results/cnn-epoch-comparison.csv), and [binary-root epoch cases](results/epoch-comparison.csv).

| Selected model | Train accuracy | Validation | Test |
|---|---:|---:|---:|
| CIFAR-10 | 99.9933% | 80.48% | 80.02% |
| Cats vs Dogs | 100% | 90.54% | 89.94% |

The intended overfitting is to training data. Validation and test data remain held out. No clear double descent was established under the studied settings. The actual private repository URL must still be inserted into the PDF and instructor access arranged before final submission.

## Folder layout

- `ell409_tree/`: complete PyTorch implementation, including data preparation, training, evaluation, interpretation, and report generation.
- `configs/`: exact experiment settings, including the small synthetic verification configuration.
- `figures/`: the original capacity and epoch plots and representative root/correction-node figures for both datasets.
- `results/`: all-model tables, explicitly featured examples, compact-model provenance, timing, deployment checks, and confusion/compression/interpolation figures.
- `models/`: selected, pruned, and compact deployed classifiers for both datasets; each includes the shared CNN and preprocessing.
- `report/`: complete scientific report.
- `docs/`, `notebooks/`, `scripts/`, `tests/`: methodology, cloud support, execution helpers, and verification.
- `supplementary/full-records.zip`: every original package file, including all repeated seeds, detailed histories, split manifests, and audit records.

## Run and reproduce

Use Python 3.12, install an appropriate PyTorch build, then:

```text
python -m pip install -e ".[test,cats]"
python -m ell409_tree doctor
python -m pytest -q
python -m ell409_tree predict --deployment models/cifar10/adaptive-w64.pt --image YOUR_IMAGE.png
python -m ell409_tree predict --deployment models/cats_vs_dogs/adaptive-w64.pt --image YOUR_IMAGE.jpg
```

For a fresh training reproduction, use new run directories:

```text
python -m ell409_tree prepare cifar10
python -m ell409_tree run --manifest data/cifar10/manifest.json --config configs/cifar10.json --run-dir runs/new-cifar10 --finalize
python -m ell409_tree prepare cats_vs_dogs
python -m ell409_tree run --manifest data/cats_vs_dogs/manifest.json --config configs/cats_vs_dogs.json --run-dir runs/new-cats-vs-dogs --finalize
```

The archived original README documents Windows TensorFlow preparation workarounds and the separate binary epoch studies. Image data and optimizer checkpoints are not in the upload folder. Full training checkpoints remain in the original local workspace.

To regenerate comparison plots from saved measurements, extract `supplementary/full-records.zip` into `supplementary/full-records/`, then:

```text
python -m ell409_tree figures --runs-root supplementary/full-records/evidence --output-dir supplementary/full-records/results
```

To add the real GitHub URL after repository creation, substitute your actual URL:

```text
python -m ell409_tree report --runs-root supplementary/full-records/evidence --output report/ELL409_Neural_Tree_Report.pdf --repository-url https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY --final
```

Upload this folder's contents as the repository root, keep the repository private, arrange grader access, and submit the updated PDF through the course channel. `UPLOAD_MANIFEST.json` hashes the prepared visible files; updating the PDF later requires updating that integrity record if desired.
"""


def guide(rows):
    text = ["# Assignment and experiment guide", "",
        "## Overfitting and interpolation", "",
        "We deliberately fit the training split and measure generalization on held-out validation/test splits. We do not fit test labels. Interpolation means zero training classification errors; it does not require zero cross-entropy.", "",
        "The selected correction models have 3/45,000 CIFAR training errors and 0/18,608 Cats vs Dogs errors, while their test errors are 19.98% and about 10.06%. This is the training/held-out gap required for the memorization investigation.", "",
        "`results/featured-cases.json` exposes both CNN baselines, roots, selected correction models, compression models, and initial sweep widths 8/128/512. These widths are displayed by their predeclared capacity positions, not chosen for favorable test accuracy. `model-comparison.csv` retains every one of the 62 candidates, including unfavorable results.", "",
        "## Double-descent procedure", "",
        "Freeze a common CNN, keep splits and optimizer protocol fixed, allocate depth-two correction trees, and train widths 8/16/32/64/128/256/512 from scratch. Plot training and validation error against total allocated parameters. Mark the first zero-training-error model. Look for an initial fall, a near-interpolation rise, and a later fall in validation error, assessing optimization and repeated-seed variability before interpreting small wiggles.", "",
        "The qualitative saved criterion requires each change to exceed max(0.5 percentage points, twice the largest standard error of the compared seed means). This is a screening rule, not a significance test. Active topology changes and inactive positions limit nominal capacity interpretations.", "",
        "Initial base training uses 100 epochs; the longer study uses 300. Parent correction training remains at 150. Selected widths have seeds 409/410/411. Both datasets reach initial primary-seed interpolation at width 128; the extended thresholds are width 32 for CIFAR and 16 for Cats vs Dogs. No clear double descent was established. The smallest initial widths already have near-perfect fit, so strongly underfitting capacities are poorly sampled. Remaining convergence flags limit strong conclusions.", "",
        "Original seed-aggregated curves: `figures/DATASET/sweep.png` and `sweep-long.png`. New explanatory primary-seed curves: `results/figures/DATASET-interpolation-comparison.png`; separate training/validation scales reveal small training-error changes. Exact values for every width in both budgets are in `capacity-comparison.csv`.", "",
        "### Initial primary seed 409", "",
        "| Dataset | Width | Training errors | Training error (%) | Validation error (%) |",
        "|---|---:|---:|---:|---:|"]
    for r in rows:
        if r["study"] == "sweep":
            text.append(f"| {r['dataset']} | {r['width']} | {r['train_errors']} | {r['train_error_percent']:.4f} | {r['validation_error_percent']:.4f} |")
    text += ["", "## Training-time comparisons", "",
        "CNN epoch curves and `cnn-epoch-comparison.csv` expose higher-training-error early checkpoints. Binary root-only widths 8/64/512 were separately followed for 300 epochs. Their early/late measurements are visible in `epoch-comparison.csv`, and their full curves in `figures/DATASET/root-epochs-wWIDTH.png`. CIFAR's binary task is cat versus the other nine classes; Cats vs Dogs uses dog versus cat. These are not final recursive multiclass tree trajectories. Increasing held-out BCE despite similar classification error is consistent with increasingly confident wrong scores and does not itself establish double descent.", "",
        "## Sequential feature-design rationale", "",
        "1. Small node networks need an informative low-dimensional input instead of thousands of raw pixels.",
        "2. Train a compact CNN from scratch on each dataset to learn the shared representation.",
        "3. Share it across all nodes and all ten CIFAR roots: independent trunks would increase compute/parameters, and deeper correction tasks may contain only a few examples.",
        "4. Freeze the CNN, pool to 128 features, normalize using training statistics, and cache vectors for inexpensive recursive node training on a 4 GB RTX 2050.",
        "5. Keep those features identical across each capacity study, and retain the CNN for image-level gradient/occlusion maps.",
        "6. Recognize the tradeoff: correction nodes cannot recover information absent from the frozen features; separate/adapted trunks remain a future comparison. Shared CNN features are an explicitly permitted design choice, not a claim of a new feature-learning method.", "",
        "## Size-reduction experiments", "",
        "Prune correction subtrees, accepting removal only if validation accuracy stays within 0.5 percentage points of the original selected model (cumulative tolerance). CIFAR falls from 24 to 10 nodes and 486,784 to 370,248 parameters (23.94%); Cats vs Dogs falls from 6 to 1 node and 336,952 to 295,332 parameters (12.35%). Validation accuracy is unchanged; training accuracy becomes 99.9711% and 99.9678%, respectively.", "",
        "Retrain widths 32 and 16: CIFAR needs 50 and 89 nodes, and Cats vs Dogs needs 10 and 11. Smaller node width therefore need not yield a smaller whole classifier. Parameter, file-size, accuracy, and timing comparisons are retained.", "",
        "Remove only inactive positions from the smallest tested qualifying active models: CIFAR width 16 has 316,184 actual parameters; Cats vs Dogs width 8 has 292,228. Their full train/validation scores are unchanged after compaction. Their existing source test results are inherited; no new test-guided selection or evaluation occurs. All totals count the shared CNN once. These are smallest found models, not globally minimal networks.", "",
        "## Archive and evidence", "",
        "`supplementary/full-records.zip` includes every original file. The visible package remains runnable, and the complete PDF already presents all locked results. Nothing is archived to hide a failed experiment. The private repository URL remains pending in the unchanged report.", ""]
    return "\n".join(text)


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "github-upload" / "ELL409-neural-tree")
    parser.add_argument("--output", type=Path, default=root / "github-upload" / "ELL409-professor-view")
    parser.add_argument("--refresh", action="store_true", help="Refresh only an unchanged generated review folder, without deleting files")
    args = parser.parse_args()
    build(args.source, args.output, args.refresh)
