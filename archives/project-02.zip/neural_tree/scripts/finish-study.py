"""Finish queued local studies sequentially without two writers to a checkpoint.

Run after an existing CNN-only process completes, or supply --wait-pid.
This is a finite runner, not a recurring scheduler/notification service.
"""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wait-pid", type=int, nargs="+")
    parser.add_argument("--datasets", nargs="+", default=["cifar10", "cats_vs_dogs"])
    parser.add_argument("--wait-data", action="store_true")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    os.chdir(project)
    for pid in args.wait_pid or []:
        import psutil
        try:
            process = psutil.Process(pid)
            print(f"Waiting for existing training process {pid}", flush=True)
            while process.is_running() and process.status() != psutil.STATUS_ZOMBIE:
                time.sleep(15)
        except psutil.NoSuchProcess:
            pass
    for dataset in args.datasets:
        manifest = Path("data") / dataset / "manifest.json"
        while args.wait_data and not manifest.exists():
            print(f"Waiting for {dataset} data preparation", flush=True)
            time.sleep(30)
        if not manifest.exists():
            raise FileNotFoundError(f"Prepare {dataset} before training")
        command = [sys.executable, "-u", "-m", "ell409_tree", "run", "--manifest", str(manifest),
                   "--config", f"configs/{dataset}.json", "--run-dir", f"runs/{dataset}", "--finalize"]
        subprocess.run(command, check=True)
        subprocess.run([sys.executable, "-m", "ell409_tree", "report", "--runs-root", "runs",
                        "--output", "output/ELL409_Neural_Tree_Report.pdf"], check=True)
    print("Both finite studies finished; add the real private repository URL and review the report.", flush=True)


if __name__ == "__main__":
    main()
