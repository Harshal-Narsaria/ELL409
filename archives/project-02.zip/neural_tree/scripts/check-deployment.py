"""Validate selected image deployments on full TRAIN/VALIDATION only, without fitting."""
from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader

from ell409_tree.common import choose_device, load_checkpoint, read_json, seed_everything, write_json
from ell409_tree.data import ImageSplit, open_record
from ell409_tree.models import TreeClassifier, ImageTreeClassifier


class RawImages(ImageSplit):
    def __getitem__(self, index):
        record = self.records[index]
        if "index" in record and self.arrays is None:
            self.arrays = np.load(self.folder / "images.npy", mmap_mode="r")
        size = self.manifest["resolution"]
        image = open_record(self.folder, record, self.arrays).resize((size, size), Image.Resampling.BILINEAR)
        tensor = torch.from_numpy(np.asarray(image, dtype=np.float32).copy()).permute(2, 0, 1) / 255
        return tensor, record["label"], index


root = Path(__file__).resolve().parents[1]
device = choose_device("auto")
seed_everything(409)
result = {"method": "Selected frozen deployment on actual RGB images; train and validation only; no fitting or test access", "datasets": {}}
with torch.inference_mode():
    for dataset in ("cifar10", "cats_vs_dogs"):
        run = root / "runs" / dataset
        name = read_json(run / "selected-tree.json")["name"]
        bundle = load_checkpoint(run / name / "deployment.pt")
        cache = load_checkpoint(run / "features.pt")
        tree = TreeClassifier.from_spec(bundle["spec"])
        tree.load_state_dict(bundle["model"])
        model = ImageTreeClassifier(tree, bundle).to(device).eval()
        batch_size = read_json(run / "configuration.json")["config"]["image_batch_size"]
        splits = {}
        for split in ("train", "validation"):
            data = RawImages(root / "data" / dataset / "manifest.json", split)
            loader = DataLoader(data, batch_size=batch_size, shuffle=False, pin_memory=device.type == "cuda")
            errors, cached_errors, disagreements, count = 0, 0, 0, 0
            before = time.perf_counter()
            for images, labels, indices in loader:
                images, labels = images.to(device), labels.to(device)
                if not torch.equal(cache["splits"][split]["y"][indices], labels.cpu()):
                    raise ValueError("Manifest/cache example order changed")
                prediction = model.predict(images)
                cached = model.tree.predict(cache["splits"][split]["x"][indices].to(device))
                errors += int((prediction != labels).sum())
                cached_errors += int((cached != labels).sum())
                disagreements += int((prediction != cached).sum())
                count += len(labels)
            splits[split] = {"examples": count, "image_errors": errors, "image_accuracy": 1 - errors / count,
                             "cached_errors_same_batch": cached_errors, "prediction_disagreements": disagreements,
                             "batch_size": batch_size, "seconds": time.perf_counter() - before}
            print(f"Deployment check {dataset}/{split}: {errors}/{count} image errors; {disagreements} cache-image prediction differences", flush=True)
        result["datasets"][dataset] = {"model": name, "splits": splits}
write_json(root / "results" / "deployment-check.json", result)
