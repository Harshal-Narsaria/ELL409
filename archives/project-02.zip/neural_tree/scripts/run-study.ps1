param(
    [ValidateSet('cifar10','cats_vs_dogs')][string]$Dataset = 'cifar10',
    [ValidateSet('all','cnn','features','trees','sweep','compress','plots')][string]$Stage = 'all',
    [string]$Python = '',
    [switch]$Prepare,
    [switch]$Finalize,
    [switch]$Background
)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
if (-not $Python) {
    $candidates = @((Join-Path $project '.venv/Scripts/python.exe'), (Join-Path $project '../.venv/Scripts/python.exe'))
    $Python = $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $Python) { throw 'Supply -Python with the path to a Python environment containing this project.' }
}
$Python = (Resolve-Path -LiteralPath $Python).Path
Set-Location -LiteralPath $project
if ($Prepare) {
    & $Python -m ell409_tree prepare $Dataset
    if ($LASTEXITCODE -ne 0) { throw 'Data preparation failed.' }
}
$runDir = "runs/$Dataset"
$arguments = @('-u','-m','ell409_tree','run','--manifest',"data/$Dataset/manifest.json",'--config',"configs/$Dataset.json",'--run-dir',$runDir,'--stage',$Stage)
if ($Finalize) { $arguments += '--finalize' }
if ($Background) {
    New-Item -ItemType Directory -Force -Path $runDir | Out-Null
    $process = Start-Process -FilePath $Python -ArgumentList $arguments -WorkingDirectory $project -WindowStyle Hidden -PassThru -RedirectStandardOutput "$runDir/stdout.log" -RedirectStandardError "$runDir/stderr.log"
    Write-Output "Training process $($process.Id). Progress: $project/$runDir/stdout.log"
} else {
    & $Python @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Training failed. Check the last error; complete epochs are resumable.' }
}
