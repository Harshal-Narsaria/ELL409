"""Copy a run directory to persistent storage between notebook sessions."""
import argparse
import os
import shutil
import time
from pathlib import Path


def snapshot(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    if source == destination or source in destination.parents:
        raise ValueError("Destination must be outside the source run folder")
    for path in source.rglob("*"):
        if not path.is_file() or path.suffix == ".tmp":
            continue
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + ".copying")
        for attempt in range(3):
            try:
                shutil.copy2(path, temporary)
                os.replace(temporary, target)
                break
            except (FileNotFoundError, PermissionError):
                if attempt == 2:
                    raise
                time.sleep(.2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source"); parser.add_argument("destination")
    parser.add_argument("--interval", type=int, default=0, help="0 = one snapshot; otherwise seconds between copies")
    args = parser.parse_args()
    while True:
        snapshot(args.source, args.destination)
        print("Checkpoint snapshot saved", flush=True)
        if not args.interval:
            break
        time.sleep(args.interval)
