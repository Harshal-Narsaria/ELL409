param(
    [string]$Python = '',
    [string]$StudyDir = 'runs/dense-capacity-2026-10-08',
    [string]$OutputDir = 'results/dense-capacity-2026-10-08',
    [switch]$PrepareOnly,
    [switch]$Background
)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
if (-not $Python) { $Python = Join-Path $project '../.venv/Scripts/python.exe' }
$Python = (Resolve-Path -LiteralPath $Python).Path
Set-Location -LiteralPath $project
$arguments = @('-u', '-m', 'ell409_tree', 'dense-study', '--source-root', 'runs', '--study-dir', $StudyDir,
               '--output-dir', $OutputDir, '--config', 'configs/dense-study.json', '--device', 'cuda')
if ($PrepareOnly) { $arguments += '--prepare-only' }
if ($Background) {
    New-Item -ItemType Directory -Force -Path $StudyDir | Out-Null
    $process = Start-Process -FilePath $Python -ArgumentList $arguments -WorkingDirectory $project -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $StudyDir 'stdout.log') -RedirectStandardError (Join-Path $StudyDir 'stderr.log')
    Write-Output "Dense study process $($process.Id). Progress: $project/$StudyDir/progress.json"
} else {
    & $Python @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Dense study failed; completed epoch checkpoints are resumable.' }
}
