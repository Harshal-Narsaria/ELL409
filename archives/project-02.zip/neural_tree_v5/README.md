# Version 5: controlled training-label noise

This is a new experiment. Versions 1-4 and the current 88-file submission package are preserved.

The primary comparison is 15% wrong training labels against a 0% noise control, using both full datasets and the existing exact splits. The CNN feature extractor comes from Version 3: it was trained on original training labels until it first reached at least 80% accuracy, and is now frozen. Cached classifier scores are discarded. This studies **noise in downstream tree training**, not end-to-end training of a CNN on noisy labels.

New MLP roots and correction children use the same 128-dimensional features. All node widths vary together across 2, 4, 8, 16, 32, 64, 128, 256, 512 and 1024, while depth is fixed at one (three allocated nodes per binary tree). CIFAR uses ten one-versus-rest trees; Cats vs Dogs uses one binary tree. Root-only ablations provide a matched comparison without child correction. Constant zero tasks keep their allocated positions but are explicitly excluded from trained node counts; active, trained and allocated sizes are reported separately.

Labels are corrupted once, using a saved seed and a sample-ID manifest shared across all widths and optimizer seeds. Changed labels always differ from the originals. Exact duplicate feature groups share one replacement label, avoiding artificially contradictory tasks. Consequently the fraction of changed images can differ slightly from 15%; the exact count is saved. Training images are unchanged, and validation/test labels are unchanged. Feature normalization continues to use training data only.

Each node gets 400 epochs of Adam with no dropout, weight decay, smoothing or augmentation. Parent coefficients use the existing signed fitting method. A training-error-first checkpoint criterion is used. Optimizer states, RNG states and node histories allow restart after interruption. Models still learning at the budget limit receive convergence flags and need further investigation before attributing differences to capacity.

Repeat widths below, at and above the first observed zero training error are selected using training metrics only. If no configuration interpolates, three predeclared coverage widths are repeated instead. Two additional optimizer seeds give three seeds including the primary run; these repeats share one corruption map and CNN checkpoint, so uncertainty is conditional on both. Test evaluation is delayed until both complete grids and repeats finish for each dataset; previous test use makes these exploratory results.

The graphs show training error against the study labels, training error against original labels, original-label validation error and original-label test error versus total deployed parameters. Frozen CNN parameters are counted once, with active capacity separately recorded in the CSV. No line smoothing, fabricated points or promised double descent.

## Start or resume on Windows

From this folder:

```powershell
& '..\.venv\Scripts\python.exe' -B -u noise_study.py
```

Or run `start-study.ps1`, which starts a hidden background process with persistent log files and refuses duplicate workers through an OS file lock. Check `runs/label-noise/progress.json`, `runs/label-noise/worker.log`, and `results/label-noise/` for progress and plots.

The laptop must remain awake and plugged in. Closing Codex does not stop the independently launched worker; sleep or hibernation pauses computation. There is no unattended wake-from-sleep service. Running the same command resumes saved work if the worker has stopped.

Do not overwrite the previous report with incomplete results. Once this study finishes and has been audited, its measurements and conclusions can be added to the report and compact GitHub package.
