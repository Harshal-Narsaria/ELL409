$ErrorActionPreference = 'Stop'
$taskProject = $PSScriptRoot
$taskRun = Join-Path $taskProject 'runs/label-noise'
$taskPython = Join-Path (Split-Path $taskProject -Parent) '.venv/Scripts/python.exe'
New-Item -ItemType Directory -Path $taskRun -Force | Out-Null
Push-Location $taskProject
try {
    & $taskPython -B -c "from pathlib import Path; import noise_study as s; lock=s.study_lock(Path('runs/label-noise/runner.lock')); lock.__enter__(); lock.__exit__(None,None,None)"
    if ($LASTEXITCODE -ne 0) { throw 'A worker already holds the study lock, or the startup check failed.' }
    $taskProcess = Start-Process -FilePath $taskPython -ArgumentList @('-B','-u','noise_study.py') -WorkingDirectory $taskProject -WindowStyle Hidden -RedirectStandardOutput (Join-Path $taskRun 'worker.log') -RedirectStandardError (Join-Path $taskRun 'worker-errors.log') -PassThru
    Write-Output "Started noise study worker: $($taskProcess.Id). Progress: $taskRun/progress.json"
} finally {
    Pop-Location
}
