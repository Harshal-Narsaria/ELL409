"""Read completed experiment snapshots and audit all available descent curves."""
from __future__ import annotations
import ctypes
from ctypes import wintypes
import hashlib
import io
import json
import os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'graphs').mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(OUT/'matplotlib-cache')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from reportlab.lib.pagesizes import landscape,A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image

plt.rcParams.update({'font.size':11,'axes.labelsize':10,'axes.titlesize':11,'legend.fontsize':8.5,'xtick.labelsize':9,'ytick.labelsize':9})
STAMP=datetime.now(ZoneInfo('Asia/Kolkata')).strftime('%d October %Y, %I:%M %p IST')
SOURCES={}
INVENTORY=[]
DS=['cifar10','cats_vs_dogs']
NAMES={'cifar10':'CIFAR-10','cats_vs_dogs':'Cats vs Dogs'}
COLORS={'train':'#24847d','validation':'#d38225','test':'#315d9f'}


def shared_bytes(path):
    if os.name!='nt':return path.read_bytes()
    import msvcrt
    api=ctypes.WinDLL('kernel32',use_last_error=True)
    create=api.CreateFileW
    create.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
    create.restype=wintypes.HANDLE
    handle=create(str(path),0x80000000,7,None,3,0x80,None)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    with os.fdopen(msvcrt.open_osfhandle(handle,os.O_RDONLY|os.O_BINARY),'rb') as f:return f.read()


def load(rel):
    raw=shared_bytes(ROOT/rel)
    SOURCES[str(Path(rel).as_posix())]=hashlib.sha256(raw).hexdigest()
    return json.loads(raw.decode('utf-8-sig'))


V1=load('neural_tree/results/analysis.json')['datasets']
COMPACT=load('neural_tree/results/compact-models.json')
DENSE=load('neural_tree/results/dense-capacity-2026-10-08/measurements.json')
V2={key:load(f'neural_tree_v2/results/{key}/measurements.json') for key in ['image-tree-v2','tree-budget-v2']}
V3={ds:load(f'neural_tree_v3/results/cnn80-depth/{ds}/measurements.json') for ds in DS}
FOLLOW=load('neural_tree_v3/results/width32-followup/cifar10/measurements.json')
FOLLOW_SEEDS=load('neural_tree_v3/results/width32-followup/cifar10/seed-summary.json')
V4={ds:(load(f'neural_tree_v4/results/random-cnn/{ds}/measurements.json') if (ROOT/f'neural_tree_v4/results/random-cnn/{ds}/measurements.json').exists() else []) for ds in DS}
STATUS=load('neural_tree_v4/runs/random-cnn/progress.json')
ROOT_HIST={ds:{w:load(f'neural_tree/runs/{ds}/root-epoch-history/w{w}.json')['history'] for w in [8,64,512]} for ds in DS}
CNN_HIST={ds:load(f'neural_tree/runs/{ds}/cnn-history.json') for ds in DS}


def seed(r):return r.get('seed',r.get('config',{}).get('seed',409))
def width(r):return r.get('width',r.get('config',{}).get('width',0))
def params(r):return r.get('total_parameters',r['size'].get('active_parameters',r['size'].get('parameters',0)))
def error(r,s):
    if not r.get(s):return None
    return 100*(1-r[s]['accuracy'])
def measure_x(r,key):return params(r) if key=='parameters' else r['depth_limit'] if key=='depth' else width(r)


def finish_axis(ax,xlabel):
    ax.set_xlabel(xlabel);ax.grid(alpha=.2)


def axis_scale(ax,rows,key):
    vals=[measure_x(r,key) for r in rows]
    if key=='width':
        ax.set_xscale('log',base=2)
        ticks=sorted(set(vals))
        if len(ticks)>9:ticks=[1,4,16,64,256,512]
        ax.set_xticks(ticks,[str(x) for x in ticks])
        ax.xaxis.set_minor_formatter(NullFormatter())
    if key=='parameters':
        ax.set_xscale('log');lo,hi=min(vals),max(vals)
        if hi>lo:
            ticks=np.geomspace(lo,hi,4)
            ax.set_xticks(ticks,[f'{v/1e6:.2g}M' if v>=1e6 else f'{v/1e3:.0f}k' for v in ticks])
            ax.xaxis.set_minor_formatter(NullFormatter())


def no_data(ax,label):
    ax.axis('off');ax.text(.5,.55,label,ha='center',va='center',transform=ax.transAxes,fontsize=12,color='#53616b',wrap=True)


def curve(ax,rows,key,train=False,means=False,root=False):
    if not rows:
        no_data(ax,'No completed measurements available\nat this snapshot');return
    primary=sorted([r for r in rows if seed(r)==409],key=lambda r:measure_x(r,key))
    splits=['train'] if train else ['validation','test']
    for split in splits:
        if not all(error(r,split) is not None for r in primary):continue
        if means and key=='width':
            xx=sorted({width(r) for r in rows});yy=[];se=[];nn=[]
            for w in xx:
                values=[error(r,split) for r in rows if width(r)==w and error(r,split) is not None]
                yy.append(float(np.mean(values)));nn.append(len(values))
                se.append(float(np.std(values,ddof=1)/np.sqrt(len(values))) if len(values)>1 else 0)
            ax.errorbar(xx,yy,yerr=se,color=COLORS[split],fmt='o-',lw=1.7,capsize=3,markersize=4,label=split.capitalize()+' mean; SE where repeated')
        else:
            ax.plot([measure_x(r,key) for r in primary],[error(r,split) for r in primary],'o-',color=COLORS[split],markersize=4,lw=1.8,label=split.capitalize())
    if root and not train and all(r.get('root_ablation') for r in primary):
        ax.plot([measure_x(r,key) for r in primary],[100*(1-r['root_ablation']['validation']['accuracy']) for r in primary],'s--',color='#777',markersize=3,label='Identical roots: validation')
    zero=next((r for r in primary if r['train']['errors']==0),None)
    if zero:
        xpos=measure_x(zero,key)
        if key=='parameters':
            # Interpolation may not define a threshold when topology is adaptive.
            ax.scatter([measure_x(r,key) for r in primary if r['train']['errors']==0],
                       [error(r,'train') if train else error(r,'test') if r.get('test') else error(r,'validation') for r in primary if r['train']['errors']==0],
                       marker='*',s=70,color='#256d36',zorder=5,label='Zero training-error models')
        else:
            ax.axvline(xpos,color='#256d36',ls=':',lw=1.4,label='First primary zero train error')
    axis_scale(ax,primary,key)
    finish_axis(ax,{'width':'Hidden width','parameters':'Actual deployed parameters (log scale)','depth':'Maximum depth (root = 0)'}[key])
    ax.set_ylabel('Training error (%)' if train else 'Held-out classification error (%)')
    ax.legend(fontsize=8)


def save(name,title,draw,nrows=2,ncols=2,figsize=(11,6.4),caption=''):
    fig,axes=plt.subplots(nrows,ncols,figsize=figsize,layout='constrained',squeeze=False)
    draw(axes)
    fig.suptitle(title,fontsize=14,fontweight='bold')
    path=OUT/'graphs'/f'{name}.png';fig.savefig(path,dpi=180);plt.close(fig)
    INVENTORY.append({'file':str(path.relative_to(ROOT).as_posix()),'title':title,'caption':caption})
    return path


def standard(name,title,data,key,means=False,root=False,caption=''):
    def draw(axes):
        for j,ds in enumerate(DS):
            for i,train in enumerate([False,True]):
                if not data[ds] and name.startswith('v4-w') and any(r['experiment']=='primary' and seed(r)==409 and r['train']['errors']==0 for r in V4[ds]):
                    no_data(axes[i,j],'Not run for '+NAMES[ds]+':\ndepth-1 models reached zero training error;\nadaptive fallback was not triggered')
                    continue
                curve(axes[i,j],data[ds],key,train,means,root)
                if name.startswith('v4-') and data[ds]:
                    baseline=next((r for r in V4[ds] if r['experiment']=='baseline' and seed(r)==409),None)
                    if baseline:
                        split='train' if train else 'test'
                        axes[i,j].axhline(error(baseline,split),color='#777',ls='--',lw=1,label='Fixed root-only '+split)
                        axes[i,j].legend(fontsize=8)
                axes[i,j].set_title(NAMES[ds]+(' / training' if train else ' / validation and available test'))
    return save(name,title,draw,caption=caption)


# Preserve each capacity protocol as a separate curve; nominal width and actual size both matter.
families={}
for prefix,name,title in [('sweep-w','v1-short','V1: original short capacity sweep'),('sweep-long-w','v1-long','V1: original long capacity sweep')]:
    data={ds:[r for r in V1[ds]['models'] if r['name'].startswith(prefix)] for ds in DS}
    families[name]=data
    for key in ['width','parameters']:
        standard(name+'-'+key,title+' / '+key,data,key,means=key=='width',
                 caption='Width view: means over available seeds, SE only for repeated widths; green line uses primary seed 409. Parameter view: primary seed 409, active deployed size with the CNN counted once. Adaptive topology can reorder widths. Test records were locked in V1. Training interpolation is zero errors, not 99.5%.')
families['v1-dense']=DENSE
for key in ['width','parameters']:
    standard('v1-dense-'+key,'V1: dense validation-only extension / '+key,DENSE,key,means=key=='width',
             caption='No dense-sweep test evaluation. Available seed means/SE in width view; primary actual active size in parameter view. Some exact matching long runs are reused. Complete measured points, not a smoothed synthetic curve.')


def overview_v1(axes):
    for i,(name,label) in enumerate([('v1-short','Short sweep'),('v1-long','Long sweep'),('v1-dense','Dense extension')]):
        for j,ds in enumerate(DS):
            curve(axes[i,j],families[name][ds],'width',means=True)
            axes[i,j].set_title(label+' / '+NAMES[ds])


save('overview-v1','V1 | All capacity protocols',overview_v1,3,2,(12,10),
     'Orange = validation; blue = available locked test measurements. Dashed green = first primary zero training-error width. Error bars use SE only where repetitions exist. Dense extension has validation only.')


def v1_controls(axes):
    for j,ds in enumerate(DS):
        rows=[V1[ds]['cnn']]+[next(r for r in V1[ds]['models'] if r['name']==name) for name in ['roots-only','adaptive-w64','pruned','narrow-w16','narrow-w32']]+[COMPACT[ds]]
        labels=['CNN head','MLP roots','Tree w64','Pruned','Narrow w16','Narrow w32','Compact near-fit']
        ax=axes[0,j];pos=np.arange(len(rows))
        for shift,split in [(-.18,'validation'),(.18,'test')]:
            ax.barh(pos+shift,[error(r,split) for r in rows],height=.36,color=COLORS[split],label=split.capitalize())
        ax.set_yticks(pos,labels);ax.invert_yaxis();ax.set_title(NAMES[ds]);ax.set_xlabel('Held-out error (%)');ax.grid(axis='x',alpha=.2);ax.legend()
        ax=axes[1,j];ax.barh(pos,[error(r,'train') for r in rows],color=COLORS['train']);ax.set_yticks(pos,labels);ax.invert_yaxis();ax.set_xlabel('Training error (%)');ax.set_title(NAMES[ds]);ax.grid(axis='x',alpha=.2)


save('v1-all-model-controls','V1 | All non-sweep classifiers and size-reduction controls',v1_controls,
     caption='CNN temporary head, MLP roots, adaptive tree, subtree pruning, narrower retraining and smallest tested compact near-fit model. Different model choices and sizes: an operating-point comparison, not a controlled double-descent curve. Test records were locked in the original study.')


def cnn_epochs(axes):
    for j,ds in enumerate(DS):
        h=CNN_HIST[ds]
        for i,metric in enumerate(['error','loss']):
            ax=axes[i,j]
            for split in ['train','validation']:
                vals=[100*(1-r[split]['accuracy']) if metric=='error' else r[split]['loss'] for r in h]
                ax.plot([r['epoch'] for r in h],vals,color=COLORS[split],label=split.capitalize())
            finish_axis(ax,'CNN training epoch');ax.set_title(NAMES[ds]);ax.set_ylabel('Classification error (%)' if metric=='error' else 'Classification loss');ax.legend()


save('v1-cnn-epochs','V1 | CNN-only epoch trajectories',cnn_epochs,
     caption='Full CNN classifier histories. Validation only across epochs; final test points do not form an epoch curve. Train/test gaps or rising loss alone do not establish double descent.')


for metric in ['error','loss']:
    def root_epochs(axes,metric=metric):
        for i,ds in enumerate(DS):
            for j,w in enumerate([8,64,512]):
                h=ROOT_HIST[ds][w];ax=axes[i,j]
                for split in ['train','validation']:
                    vals=[100*(r['errors']/r['examples']) if split=='train' else 100*(r['validation']['errors']/r['validation']['examples']) for r in h] if metric=='error' else [r['loss'] if split=='train' else r['validation']['loss'] for r in h]
                    ax.plot([r['epoch'] for r in h],vals,color=COLORS[split],label=split.capitalize(),lw=1.1)
                zero=next((r['epoch'] for r in h if r['errors']==0),None)
                if zero:ax.axvline(zero,color='#256d36',ls=':',label=f'First zero train error: {zero}')
                ax.set_title(NAMES[ds]+f' / w{w}');finish_axis(ax,'Epoch');ax.set_ylabel('Binary error (%)' if metric=='error' else 'Binary BCE');ax.legend(fontsize=7.5)
    save('v1-root-epochs-'+metric,'V1 | Binary root-only epoch '+metric,root_epochs,2,3,(12,7.3),
         'CIFAR plots concern the binary cat-versus-rest root, not ten-class forest error. Cats concerns the dog binary root. Raw epoch values; no smoothing. Root tasks at widths 8, 64 and 512. Small epoch rebounds are not established epoch-wise double descent.')


for study,short,title in [('image-tree-v2','prototype','Broader-root prototype'),('tree-budget-v2','fixedroot','Fixed root width 4')]:
    data={ds:[r for r in V2[study] if r['dataset']==ds and r['name'].startswith('capacity-')] for ds in DS}
    for key in ['width','parameters']:
        standard('v2-'+short+'-'+key,'V2 | '+title+' / '+key,data,key,root=True,
                 caption='Pixel-tree capacity configurations and identical-root ablation. Validation only, one seed; adaptive topology. Prototype roots vary with width; fixed-root study preserves width 4 and 120 epochs. Neither hidden test measurements nor a new independent test benchmark are inferred.')
    def control_graph(axes,study=study):
        for j,ds in enumerate(DS):
            rows=sorted([r for r in V2[study] if r['dataset']==ds and not r['name'].startswith('capacity-')],key=lambda r:r['name'])
            labels=[r['name'].replace('main-','main ').replace('fit-','fit ').replace('pixel_tree-','pixel ').replace('hybrid-','hybrid ').replace('parameter-matched-mlp-roots','Matched MLP').replace('narrower-selected-architecture','Narrower').replace('cnn-only-roots','CNN only') for r in rows]
            for i,split in enumerate(['validation','train']):
                ax=axes[i,j];ax.barh(np.arange(len(rows)),[error(r,split) for r in rows],color=COLORS[split],alpha=.85)
                ax.set_yticks(np.arange(len(rows)),labels,fontsize=9);ax.invert_yaxis()
                ax.set_title(NAMES[ds]+' / '+split);ax.set_xlabel('Classification error (%)');ax.grid(axis='x',alpha=.2)
    save('v2-'+short+'-all-architectures','V2 | '+title+' / architecture controls',control_graph,2,2,(12,8),
         'Includes pixel trees, selective-CNN hybrid trees, CNN-only and parameter-matched controls, narrower retraining and pruning. These are operating-point comparisons; depth, epochs and architecture differ, so they are not a controlled capacity curve or evidence of double descent.')


def overview_v2(axes):
    for i,(study,label) in enumerate([('image-tree-v2','Broader root'),('tree-budget-v2','Fixed small root')]):
        for j,ds in enumerate(DS):
            rows=[r for r in V2[study] if r['dataset']==ds and r['name'].startswith('capacity-')]
            curve(axes[i,j],rows,'width',root=True);axes[i,j].set_title(label+' / '+NAMES[ds])


save('overview-v2','V2 | Pixel-tree capacity studies; local-CNN controls in atlas',overview_v2,
     caption='One seed, validation only. The prototype Cats curve has an early peak before any model reaches zero training error. Fixed-root study never reaches zero errors. Architecture controls are shown on separate atlas pages.')


for w in [32,64,128,256]:
    data={ds:[r for r in V3[ds] if r['seed']==409 and r['width']==w] for ds in DS}
    for key in ['depth','parameters']:
        standard(f'v3-w{w}-'+key,f'V3 | CNN near 80% / correction width {w} / '+key,data,key,
                 caption='Primary correction seed 409, one fixed CNN per dataset. Both train and repeatedly inspected test curves. No original V3 full forest reaches zero training errors; local held-out recoveries occur before interpolation. Equal parameter counts at later depth limits are real plateaus.')


def overview_v3(axes):
    for i,ds in enumerate(DS):
        for j,w in enumerate([32,64,128,256]):
            rows=[r for r in V3[ds] if r['seed']==409 and r['width']==w]
            curve(axes[i,j],rows,'depth');axes[i,j].set_title(NAMES[ds]+f' / w{w}')


save('overview-v3','V3 | All four correction widths, both datasets',overview_v3,2,4,(15,7.2),
     'Orange = validation; blue = exploratory test error. None reaches zero full-training error in the original fitting policy. Small late improvements must not be called post-interpolation double descent.')


def v3_repeats(axes):
    for j,ds in enumerate(DS):
        allrows=V3[ds]
        settings=sorted({(width(r),r['depth_limit']) for r in allrows if seed(r)!=409})
        for i,train in enumerate([False,True]):
            ax=axes[i,j]
            for split in ['train'] if train else ['validation','test']:
                means=[];ses=[]
                for setting in settings:
                    vals=[error(r,split) for r in allrows if (width(r),r['depth_limit'])==setting]
                    means.append(np.mean(vals));ses.append(np.std(vals,ddof=1)/np.sqrt(len(vals)))
                ax.errorbar(range(len(settings)),means,yerr=ses,fmt='o-',capsize=4,color=COLORS[split],label=split.capitalize())
            ax.set_xticks(range(len(settings)),[f'w{w}/d{d}' for w,d in settings]);ax.set_ylabel('Classification error (%)');ax.set_title(NAMES[ds]+' / three correction seeds');ax.grid(alpha=.2);ax.legend()


save('v3-original-repeats','V3 | Original depth study: representative seed repeats',v3_repeats,
     caption='Available representative settings, seeds 409/410/411, one frozen CNN. Means +/- SE, categorical width/depth labels. Repeats do not create missing interpolation or independent post-interpolation capacity.')


for key in ['depth','parameters']:
    def follow_graph(axes,key=key):
        for j,policy in enumerate(['original','classification_refit']):
            rows=[r for r in FOLLOW if r['seed']==409 and r['policy']==policy]
            for i,train in enumerate([False,True]):
                curve(axes[i,j],rows,key,train);axes[i,j].set_title('CIFAR-10 / '+policy.replace('_',' '))
    save('v3-followup-'+key,'V3 follow-up | Paired width-32 parent-fitting policies',follow_graph,
         caption='CIFAR-10 only; no Cats-vs-Dogs follow-up was run. Same CNN and learned base networks, changed signed parent fitting. Revised arm interpolates at depth 11 for seed 409. Depths 12-20 then reuse saturated capacity; perfect fit alone does not establish double descent.')


def follow_repeat(axes):
    for j,policy in enumerate(['original','classification_refit']):
        rows=[r for r in FOLLOW_SEEDS['records'] if r['policy']==policy]
        for i,split in enumerate(['test','train']):
            ax=axes[i,j];ax.errorbar([r['depth_limit'] for r in rows],[100*r[split]['mean_error'] for r in rows],yerr=[100*r[split]['standard_error'] for r in rows],fmt='o-',capsize=4,color=COLORS[split])
            finish_axis(ax,'Maximum depth');ax.set_ylabel(split.capitalize()+' error (%)');ax.set_title(policy.replace('_',' ')+' / 3 correction seeds')


save('v3-followup-repeats','V3 follow-up | Seed mean and standard error',follow_repeat,
     caption='Seeds 409, 410, 411 at depths 0, 10 and 20, conditional on one frozen CNN. Zero training error in all three revised arms at depth 20. Missing independent capacities beyond saturation and no complete mean peak/second descent.')


for key in ['width','parameters']:
    data={ds:[r for r in V4[ds] if r['experiment']=='primary'] for ds in DS}
    standard('v4-primary-'+key,'V4 | Frozen random CNN, fixed depth 1 / '+key,data,key,means=key=='width',
             caption='Completed on both datasets, widths 4-512. Fixed root and primary correction task positions. CIFAR never reaches zero training error here; Cats first does at w256 for seed409 (seed411 needs w512). Width view uses available seed means/SE, so early points have one seed and some late points three.')


for w in [16,32,64,128,256]:
    data={ds:[r for r in V4[ds] if r['experiment']=='deeper' and seed(r)==409 and width(r)==w] for ds in DS}
    for key in ['depth','parameters']:
        standard(f'v4-w{w}-'+key,f'V4 | Random features, width {w} / '+key,data,key,
                 caption='Completed CIFAR adaptive fallback, primary seed 409. Reused saturated stages retain the same model and capacity. Cats fallback was not triggered because its depth-one width sweep interpolated. Repeated test measurements are exploratory; growth and selection use training only.')


def v4_slices(axes):
    for i,ds in enumerate(DS):
        for j,d in enumerate([2,4,6,10]):
            rows=[r for r in V4[ds] if r['experiment']=='deeper' and seed(r)==409 and r['depth_limit']==d]
            if not rows and any(r['experiment']=='primary' and seed(r)==409 and r['train']['errors']==0 for r in V4[ds]):
                no_data(axes[i,j],'Cats depth fallback not run:\ndepth-1 width sweep interpolated');continue
            curve(axes[i,j],rows,'width');axes[i,j].set_title(NAMES[ds]+f' / depth {d}')


save('overview-v4-depth-slices','V4 | Compare widths at fixed maximum depth',v4_slices,2,4,(15,7.2),
     'Green line marks first zero-error width in nominal-width order, not a proven parameter threshold. Adaptive node counts change across widths. This view reveals the depth-6 CIFAR interpolation-associated peak; Cats did not need the adaptive-depth fallback.')


def v4_repeats(axes):
    for j,ds in enumerate(DS):
        for i,experiment in enumerate(['primary','deeper']):
            ax=axes[i,j];rows=[r for r in V4[ds] if r['experiment']==experiment]
            settings=sorted({(width(r),r['depth_limit']) for r in rows})
            settings=[s for s in settings if len([r for r in rows if (width(r),r['depth_limit'])==s])>1]
            if not settings:no_data(ax,'No completed repeated settings yet');continue
            for split in ['train','test']:
                means=[];ses=[]
                for setting in settings:
                    vals=[error(r,split) for r in rows if (width(r),r['depth_limit'])==setting]
                    means.append(np.mean(vals));ses.append(np.std(vals,ddof=1)/np.sqrt(len(vals)))
                ax.errorbar(range(len(settings)),means,yerr=ses,fmt='o-',capsize=4,color=COLORS[split],label=split.capitalize())
            ax.set_xticks(range(len(settings)),[f'w{w}/d{d}' for w,d in settings]);ax.set_title(NAMES[ds]+' / '+experiment);ax.set_ylabel('Error (%)');ax.grid(alpha=.2);ax.legend()


save('v4-repeats','V4 | Available correction-seed repetitions',v4_repeats,
     caption='Mean +/- SE over completed repeats only. One fixed random CNN. Different settings are categorical comparisons, not a monotone capacity ordering. In particular, width-32 depth-6 peak is not repeated by this declared repeat plan.')


def candidates(axes):
    rows=sorted([r for r in V4['cifar10'] if seed(r)==409 and r['experiment']=='deeper' and r['depth_limit']==6],key=width)
    x=[width(r) for r in rows]
    ax=axes[0,0];ax.plot(x,[error(r,'test') for r in rows],'o-',color=COLORS['test'],label='Test')
    ax.axvline(32,ls=':',color='#256d36',label='First zero training error: w32')
    axis_scale(ax,rows,'width');finish_axis(ax,'Correction hidden width');ax.set_ylabel('Test error (%)');ax.set_title('Random CNN / CIFAR / fixed depth 6');ax.legend()
    ax=axes[1,0]
    for r in rows:
        ax.scatter(params(r),error(r,'test'),marker='*' if r['train']['errors']==0 else 'o',s=95,color='#256d36' if r['train']['errors']==0 else COLORS['test'])
        ax.annotate(f'w{width(r)}',(params(r),error(r,'test')),xytext=(5,7),textcoords='offset points',fontsize=9)
    axis_scale(ax,rows,'parameters');finish_axis(ax,'Actual deployed parameters');ax.set_ylabel('Test error (%)');ax.set_title('Topology confound: width does not order size')
    cats=sorted([r for r in V4['cats_vs_dogs'] if r['experiment']=='primary' and seed(r)==409],key=width)
    ax=axes[0,1];ax.plot([width(r) for r in cats],[error(r,'test') for r in cats],'o-',color=COLORS['test'],label='Test, seed409')
    settings=sorted({width(r) for r in cats})
    for w in settings:
        vals=[error(r,'test') for r in V4['cats_vs_dogs'] if r['experiment']=='primary' and width(r)==w]
        if len(vals)>1:
            ax.errorbar(w,np.mean(vals),yerr=np.std(vals,ddof=1)/np.sqrt(len(vals)),fmt='D',capsize=4,color='#b76f18',label='3-seed mean +/- SE' if w==128 else None)
    axis_scale(ax,cats,'width');ax.axvline(256,ls=':',color='#256d36',label='First zero train error: w256')
    finish_axis(ax,'Correction hidden width');ax.set_ylabel('Test error (%)');ax.set_title('Random CNN / Cats / fixed depth 1');ax.legend(fontsize=8)
    ax=axes[1,1];ax.plot([width(r) for r in cats],[error(r,'train') for r in cats],'o-',color=COLORS['train'])
    axis_scale(ax,cats,'width');ax.axvline(256,ls=':',color='#256d36');finish_axis(ax,'Correction hidden width');ax.set_ylabel('Training error (%)');ax.set_title('Cats peak at w32 precedes interpolation at w256')


save('strongest-hints','Most relevant hints | Preliminary, not confirmed double descent',candidates,
     caption='CIFAR depth6: test error peaks at w32, the first zero-error width, then falls 1.86 pp by w256; actual size is nonmonotone. Cats depth1: error 31.08 -> 30.31 -> 33.36 -> 31.30%, with a peak at w32 but first zero training error at w256. Orange diamonds show available 3-seed means/SE, not a full-grid replication.')


# A concise plain-language result audit accompanies the complete graph collection.
FINDINGS=[
 {'study':'V1 short/long/dense','dataset':'CIFAR-10','verdict':'Weak small bumps; no convincing double descent','detail':'Long primary test error 20.22% (w8), 20.30% (w16), 20.10% (w32), then 19.67% (w512). The w16 bump is only 0.08 pp; first primary zero train error is w32. Dense validation 19.68% (w16) -> 19.74% (w24, first zero) -> 19.36% (w48) is another small hint, with adaptive size and selective repeats.'},
 {'study':'V1 short/long/dense','dataset':'Cats vs Dogs','verdict':'Weak interpolation-associated validation peak','detail':'Long mean validation error 9.4726% (w16) -> 9.8022% (w32) -> 9.3293% (w64). The 0.473 pp drop is small; w64 has one seed, earlier means have three. Dense first zero w12 shows 9.458% (w8) -> 9.544% (w12) -> 9.243% (w16), only a 0.086 pp initial rise.'},
 {'study':'V1 CNN/root epoch histories','dataset':'Both','verdict':'Small late rebounds, no robust epoch-wise double descent','detail':'Binary-root validation classification errors fluctuate; held-out BCE mostly rises after its early minimum. These are binary cat-versus-rest or dog tasks, not the global CIFAR forest. Root w8 does not interpolate within 300 epochs.'},
 {'study':'V2 broader-root prototype','dataset':'CIFAR-10','verdict':'Mostly improving validation with width, no clear peak','detail':'Pixel-tree validation improves from 40.44% to 51.98%. No primary tested width has exactly zero ten-class training errors.'},
 {'study':'V2 broader-root prototype','dataset':'Cats vs Dogs','verdict':'Early hump, but well before observed interpolation','detail':'Validation error 36.54% (w4) -> 38.01% (w8) -> 34.09% (w64). Training first reaches zero at w64, not at the w8 hump. One seed and changing roots/topology prevent a robust interpolation-linked claim.'},
 {'study':'V2 fixed-root pixel/selective CNN','dataset':'Both','verdict':'No zero-error interpolation in the tested trees','detail':'Correction children markedly improve training fit, but none of these fixed-root tree candidates reaches 100%. Local CNN and parameter-matched controls are architecture operating points, not a capacity double-descent curve.'},
 {'study':'V3 original CNN-near-80%','dataset':'CIFAR-10','verdict':'Small pre-interpolation recovery','detail':'Width 32 test error falls from 22.83% (d6) to 22.73% (d8), but training error stays about 8.79%. This is not a recovery after interpolation.'},
 {'study':'V3 original CNN-near-80%','dataset':'Cats vs Dogs','verdict':'Larger recovery, still before interpolation','detail':'Width 64 test error 20.03% (d5) -> 19.35% (d10), while d10 training error is 10.26%. Width 128 recovers 19.47% (d4) -> 18.92% (d6), also with substantial training error.'},
 {'study':'V3 width-32 paired parent refit','dataset':'CIFAR-10 only','verdict':'Perfect fitting, no independent post-interpolation capacities','detail':'Revised parent fitting reaches zero training error at d11 (seed409); later declared depths reuse saturated parameters. All three revised seeds fit at d20; the test curve has no established second descent.'},
 {'study':'V4 frozen random CNN, depth1','dataset':'CIFAR-10','verdict':'No exact interpolation, no sustained second descent','detail':'Training fit reaches 99.61% at w512 but still has 174 errors. Test error is generally worse at the larger widths.'},
 {'study':'V4 frozen random CNN, depth6','dataset':'CIFAR-10','verdict':'Most interesting current hint: interpolation-associated peak','detail':'Width-order test error 51.34 -> 52.60 -> 51.25 -> 50.89 -> 50.74%, for widths16/32/64/128/256. First width with zero errors is32. Peak-to-largest-width drop is1.86 pp. Adaptive topology makes parameters nonmonotone, the width32 peak is not repeated, the first descent is undersampled, and test is reused.'},
 {'study':'V4 frozen random CNN, depth1','dataset':'Cats vs Dogs','verdict':'Clearer double-descent-like shape, but peak precedes interpolation','detail':'Primary test error 31.08% (w4) -> 30.31% (w16) -> 33.36% (w32) -> 31.30% (w512). Peak-to-last drop is2.064 pp. Topology is fixed at3 nodes and parameters increase with width. First zero train error is w256, far after the w32 peak. Repeats at128/256/512 give mean test errors about33.02/33.02/32.44%; the peak and lower-width region were not repeated. Mean late improvement is0.57 pp, with overlapping SE. Completed study, still exploratory rather than confirmed double descent.'},
]

SNAPSHOT={'timestamp':STAMP,'v1':V1,'dense':DENSE,'v2':V2,'v3':V3,'followup':FOLLOW,'v4':V4,'v4_status':STATUS,
          'root_histories':ROOT_HIST,'cnn_histories':CNN_HIST,'findings':FINDINGS,'sources_sha256':SOURCES,'graphs':INVENTORY}
(OUT/'audit-snapshot.json').write_text(json.dumps(SNAPSHOT,indent=2),encoding='utf-8')
(OUT/'graph-inventory.json').write_text(json.dumps(INVENTORY,indent=2),encoding='utf-8')
md=['# Double descent: complete graph audit','',f'Evidence snapshot: {STAMP}','',
    'Weak indications existed. The clearest shapes are the CIFAR random-CNN depth-six width slice and the Cats random-CNN depth-one width sweep. Neither establishes confirmed post-interpolation double descent. Both dataset studies are complete.','',
    'Lower error is better. Interpolation means zero errors on the entire designated training split. All figures use actual completed observations; no curve smoothing or missing results are invented.','']
for f in FINDINGS:md += [f"## {f['study']} / {f['dataset']}",f"**{f['verdict']}**",f['detail'],'']
md+=['## Graph inventory','']
for item in INVENTORY:md += [f"- {item['title']}: [{Path(item['file']).name}](graphs/{Path(item['file']).name})"]
(OUT/'DOUBLE_DESCENT_FINDINGS.md').write_text('\n'.join(md),encoding='utf-8')

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='AuditTitle',fontSize=20,leading=24,textColor=colors.HexColor('#173c4d'),spaceAfter=10))
styles.add(ParagraphStyle(name='AuditBody',fontSize=10,leading=14,spaceAfter=9))
styles.add(ParagraphStyle(name='AuditSmall',fontSize=8.5,leading=11,spaceAfter=7))
story=[]
def paragraph(t,style='AuditBody'):story.append(Paragraph(escape(t),styles[style]))
paragraph('Double descent: complete graph atlas','AuditTitle')
paragraph('ELL409 | All saved model families and both datasets | '+STAMP)
paragraph('Weak indications existed, but no robust double descent is established. The most interesting hints are the random-CNN fixed-depth-six CIFAR width slice and the fixed-depth-one Cats width sweep. CIFAR has a topology/size confound; the Cats peak occurs before observed interpolation. Both random-CNN dataset studies are now complete.')
paragraph('Reading the figures: lower classification error is better. Green dashed lines mark the first primary zero-training-error point along width/depth. Green stars in parameter plots mark zero-error models without claiming a unique capacity threshold. Training panels verify interpolation separately from held-out curve shape.')
paragraph('The atlas includes short/long/dense capacity studies, CNN and binary-root epoch histories, pixel and selective-CNN controls, all four CNN-near-80% widths, the paired parent refit, and complete random-CNN primary/deeper/repeat results. A model with only one operating point cannot provide a double-descent curve; those controls are shown as bars. Cats required no random-feature depth fallback; those unrun conditions are explicitly labelled.')
paragraph('Test evidence policy: V1 test candidates were locked; the dense addendum and V2 use validation. V3/V4 tests are repeatedly inspected exploratory partitions. Seed repeats are conditional on one frozen CNN. No new training or model selection is performed by this audit.','AuditSmall')
story.append(PageBreak())
paragraph('Evidence assessment by experiment','AuditTitle')
for f in FINDINGS[:6]:
    paragraph(f['study']+' / '+f['dataset']+': '+f['verdict'])
    paragraph(f['detail'],'AuditSmall')
story.append(PageBreak())
paragraph('Later studies and the strongest current hint','AuditTitle')
for f in FINDINGS[6:]:
    paragraph(f['study']+' / '+f['dataset']+': '+f['verdict'])
    paragraph(f['detail'],'AuditSmall')
ordered=[next(i for i in INVENTORY if i['file'].endswith('/strongest-hints.png'))]+[i for i in INVENTORY if not i['file'].endswith('/strongest-hints.png') and not Path(i['file']).name.startswith('overview-')]
for item in ordered:
    story.append(PageBreak());paragraph(item['title'],'AuditTitle')
    raw=shared_bytes(ROOT/item['file']);image=ImageReader(io.BytesIO(raw));w,h=image.getSize();scale=min(756/w,385/h)
    story.append(Image(io.BytesIO(raw),width=w*scale,height=h*scale,hAlign='CENTER'));story.append(Spacer(1,8));paragraph(item['caption'],'AuditSmall')

def footer(canvas,doc):
    canvas.saveState();canvas.setFillColor(colors.HexColor('#567080'));canvas.setFont('Helvetica',8)
    canvas.drawString(43,21,'ELL409 | Double-descent audit | '+STAMP);canvas.drawRightString(landscape(A4)[0]-43,21,str(doc.page));canvas.restoreState()
pdf=ROOT/'output/pdf/ELL409_Double_Descent_Graph_Atlas.pdf'
SimpleDocTemplate(str(pdf),pagesize=landscape(A4),leftMargin=43,rightMargin=43,topMargin=35,bottomMargin=37,
                  title='ELL409 Double Descent: Complete Graph Audit',author='ELL409 coursework').build(story,onFirstPage=footer,onLaterPages=footer)
print(json.dumps({'pdf':str(pdf),'snapshot':STAMP,'graph_files':len(INVENTORY),'v4_stage_counts':{ds:len(V4[ds]) for ds in DS}},indent=2))
