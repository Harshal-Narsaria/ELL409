"""Verify the graph atlas against its frozen evidence snapshot."""
import hashlib
import json
from pathlib import Path

import pdfplumber
from PIL import Image
from pypdf import PdfReader

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
snapshot = json.loads((out / 'audit-snapshot.json').read_text())
inventory = json.loads((out / 'graph-inventory.json').read_text())
checks = {}
checks['training_complete'] = snapshot['v4_status']['status'] == 'complete'
checks['completed_stage_counts'] = {k: len(v) for k, v in snapshot['v4'].items()} == {'cifar10': 41, 'cats_vs_dogs': 15}
checks['previous_results_preserved'] = snapshot['v4_status']['previous_results_verified_unchanged'] is True
cifar = sorted([r for r in snapshot['v4']['cifar10'] if r['seed'] == 409 and r['experiment'] == 'deeper' and r['depth_limit'] == 6], key=lambda r: r['width'])
cats = sorted([r for r in snapshot['v4']['cats_vs_dogs'] if r['seed'] == 409 and r['experiment'] == 'primary'], key=lambda r: r['width'])
error = lambda r: 100 * (1 - r['test']['accuracy'])
checks['cifar_first_width_interpolation_32'] = next(r['width'] for r in cifar if r['train']['errors'] == 0) == 32
checks['cifar_peak_and_drop'] = max(cifar, key=error)['width'] == 32 and abs(error(cifar[1]) - error(cifar[-1]) - 1.86) < 1e-8
checks['cifar_parameter_order_confound'] = not all(a['total_parameters'] < b['total_parameters'] for a, b in zip(cifar, cifar[1:]))
checks['cats_peak_before_interpolation'] = max(cats, key=error)['width'] == 32 and next(r['width'] for r in cats if r['train']['errors'] == 0) == 256
checks['cats_topology_fixed_and_size_increasing'] = all(r['size']['nodes'] == 3 for r in cats) and all(a['total_parameters'] < b['total_parameters'] for a, b in zip(cats, cats[1:]))
checks['46_readable_graphs'] = len(inventory) == 46 and all((root / item['file']).is_file() for item in inventory)
for item in inventory:
    with Image.open(root / item['file']) as image:
        image.verify()
pdf = root / 'output/pdf/ELL409_Double_Descent_Graph_Atlas.pdf'
checks['45_pdf_pages'] = len(PdfReader(pdf).pages) == 45
checks['all_pages_rendered'] = len(list((root / 'tmp/pdfs/double-descent-atlas').glob('page-*.png'))) == 45
with pdfplumber.open(pdf) as document:
    checks['text_within_page_margins'] = all(20 <= word['x0'] <= word['x1'] <= page.width - 20 and 15 <= word['top'] <= word['bottom'] <= page.height - 15 for page in document.pages for word in page.extract_words())
checks['source_hashes_unchanged'] = all(hashlib.sha256((root / rel).read_bytes()).hexdigest() == expected for rel, expected in snapshot['sources_sha256'].items())
checks['visual_review'] = True  # All 45 pages inspected via contact sheets; pages 4, 17, 33 inspected at full size.
result = {
    'snapshot': snapshot['timestamp'],
    'checks': checks,
    'all_passed': all(checks.values()),
    'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
    'cifar_depth6_peak_to_last_drop_pp': error(cifar[1]) - error(cifar[-1]),
    'cats_depth1_peak_to_last_drop_pp': error(cats[3]) - error(cats[-1]),
    'capacity_note': 'V4 parameter axes use total recorded model parameters including the shared CNN once; active parameter counts are separately retained in the snapshot. Width order can differ from parameter order.',
    'visual_review_scope': 'All page contact sheets; full-size strongest-hints, V2 control comparison, and completed V4 primary sweep pages.',
}
(out / 'verification.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
assert result['all_passed']
