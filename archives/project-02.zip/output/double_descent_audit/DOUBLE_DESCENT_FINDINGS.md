# Double descent: complete graph audit

Evidence snapshot: 09 October 2026, 07:00 PM IST

Weak indications existed. The clearest shapes are the CIFAR random-CNN depth-six width slice and the Cats random-CNN depth-one width sweep. Neither establishes confirmed post-interpolation double descent. Both dataset studies are complete.

Lower error is better. Interpolation means zero errors on the entire designated training split. All figures use actual completed observations; no curve smoothing or missing results are invented.

## V1 short/long/dense / CIFAR-10
**Weak small bumps; no convincing double descent**
Long primary test error 20.22% (w8), 20.30% (w16), 20.10% (w32), then 19.67% (w512). The w16 bump is only 0.08 pp; first primary zero train error is w32. Dense validation 19.68% (w16) -> 19.74% (w24, first zero) -> 19.36% (w48) is another small hint, with adaptive size and selective repeats.

## V1 short/long/dense / Cats vs Dogs
**Weak interpolation-associated validation peak**
Long mean validation error 9.4726% (w16) -> 9.8022% (w32) -> 9.3293% (w64). The 0.473 pp drop is small; w64 has one seed, earlier means have three. Dense first zero w12 shows 9.458% (w8) -> 9.544% (w12) -> 9.243% (w16), only a 0.086 pp initial rise.

## V1 CNN/root epoch histories / Both
**Small late rebounds, no robust epoch-wise double descent**
Binary-root validation classification errors fluctuate; held-out BCE mostly rises after its early minimum. These are binary cat-versus-rest or dog tasks, not the global CIFAR forest. Root w8 does not interpolate within 300 epochs.

## V2 broader-root prototype / CIFAR-10
**Mostly improving validation with width, no clear peak**
Pixel-tree validation improves from 40.44% to 51.98%. No primary tested width has exactly zero ten-class training errors.

## V2 broader-root prototype / Cats vs Dogs
**Early hump, but well before observed interpolation**
Validation error 36.54% (w4) -> 38.01% (w8) -> 34.09% (w64). Training first reaches zero at w64, not at the w8 hump. One seed and changing roots/topology prevent a robust interpolation-linked claim.

## V2 fixed-root pixel/selective CNN / Both
**No zero-error interpolation in the tested trees**
Correction children markedly improve training fit, but none of these fixed-root tree candidates reaches 100%. Local CNN and parameter-matched controls are architecture operating points, not a capacity double-descent curve.

## V3 original CNN-near-80% / CIFAR-10
**Small pre-interpolation recovery**
Width 32 test error falls from 22.83% (d6) to 22.73% (d8), but training error stays about 8.79%. This is not a recovery after interpolation.

## V3 original CNN-near-80% / Cats vs Dogs
**Larger recovery, still before interpolation**
Width 64 test error 20.03% (d5) -> 19.35% (d10), while d10 training error is 10.26%. Width 128 recovers 19.47% (d4) -> 18.92% (d6), also with substantial training error.

## V3 width-32 paired parent refit / CIFAR-10 only
**Perfect fitting, no independent post-interpolation capacities**
Revised parent fitting reaches zero training error at d11 (seed409); later declared depths reuse saturated parameters. All three revised seeds fit at d20; the test curve has no established second descent.

## V4 frozen random CNN, depth1 / CIFAR-10
**No exact interpolation, no sustained second descent**
Training fit reaches 99.61% at w512 but still has 174 errors. Test error is generally worse at the larger widths.

## V4 frozen random CNN, depth6 / CIFAR-10
**Most interesting current hint: interpolation-associated peak**
Width-order test error 51.34 -> 52.60 -> 51.25 -> 50.89 -> 50.74%, for widths16/32/64/128/256. First width with zero errors is32. Peak-to-largest-width drop is1.86 pp. Adaptive topology makes parameters nonmonotone, the width32 peak is not repeated, the first descent is undersampled, and test is reused.

## V4 frozen random CNN, depth1 / Cats vs Dogs
**Clearer double-descent-like shape, but peak precedes interpolation**
Primary test error 31.08% (w4) -> 30.31% (w16) -> 33.36% (w32) -> 31.30% (w512). Peak-to-last drop is2.064 pp. Topology is fixed at3 nodes and parameters increase with width. First zero train error is w256, far after the w32 peak. Repeats at128/256/512 give mean test errors about33.02/33.02/32.44%; the peak and lower-width region were not repeated. Mean late improvement is0.57 pp, with overlapping SE. Completed study, still exploratory rather than confirmed double descent.

## Graph inventory

- V1: original short capacity sweep / width: [v1-short-width.png](graphs/v1-short-width.png)
- V1: original short capacity sweep / parameters: [v1-short-parameters.png](graphs/v1-short-parameters.png)
- V1: original long capacity sweep / width: [v1-long-width.png](graphs/v1-long-width.png)
- V1: original long capacity sweep / parameters: [v1-long-parameters.png](graphs/v1-long-parameters.png)
- V1: dense validation-only extension / width: [v1-dense-width.png](graphs/v1-dense-width.png)
- V1: dense validation-only extension / parameters: [v1-dense-parameters.png](graphs/v1-dense-parameters.png)
- V1 | All capacity protocols: [overview-v1.png](graphs/overview-v1.png)
- V1 | All non-sweep classifiers and size-reduction controls: [v1-all-model-controls.png](graphs/v1-all-model-controls.png)
- V1 | CNN-only epoch trajectories: [v1-cnn-epochs.png](graphs/v1-cnn-epochs.png)
- V1 | Binary root-only epoch error: [v1-root-epochs-error.png](graphs/v1-root-epochs-error.png)
- V1 | Binary root-only epoch loss: [v1-root-epochs-loss.png](graphs/v1-root-epochs-loss.png)
- V2 | Broader-root prototype / width: [v2-prototype-width.png](graphs/v2-prototype-width.png)
- V2 | Broader-root prototype / parameters: [v2-prototype-parameters.png](graphs/v2-prototype-parameters.png)
- V2 | Broader-root prototype / architecture controls: [v2-prototype-all-architectures.png](graphs/v2-prototype-all-architectures.png)
- V2 | Fixed root width 4 / width: [v2-fixedroot-width.png](graphs/v2-fixedroot-width.png)
- V2 | Fixed root width 4 / parameters: [v2-fixedroot-parameters.png](graphs/v2-fixedroot-parameters.png)
- V2 | Fixed root width 4 / architecture controls: [v2-fixedroot-all-architectures.png](graphs/v2-fixedroot-all-architectures.png)
- V2 | Pixel-tree capacity studies; local-CNN controls in atlas: [overview-v2.png](graphs/overview-v2.png)
- V3 | CNN near 80% / correction width 32 / depth: [v3-w32-depth.png](graphs/v3-w32-depth.png)
- V3 | CNN near 80% / correction width 32 / parameters: [v3-w32-parameters.png](graphs/v3-w32-parameters.png)
- V3 | CNN near 80% / correction width 64 / depth: [v3-w64-depth.png](graphs/v3-w64-depth.png)
- V3 | CNN near 80% / correction width 64 / parameters: [v3-w64-parameters.png](graphs/v3-w64-parameters.png)
- V3 | CNN near 80% / correction width 128 / depth: [v3-w128-depth.png](graphs/v3-w128-depth.png)
- V3 | CNN near 80% / correction width 128 / parameters: [v3-w128-parameters.png](graphs/v3-w128-parameters.png)
- V3 | CNN near 80% / correction width 256 / depth: [v3-w256-depth.png](graphs/v3-w256-depth.png)
- V3 | CNN near 80% / correction width 256 / parameters: [v3-w256-parameters.png](graphs/v3-w256-parameters.png)
- V3 | All four correction widths, both datasets: [overview-v3.png](graphs/overview-v3.png)
- V3 | Original depth study: representative seed repeats: [v3-original-repeats.png](graphs/v3-original-repeats.png)
- V3 follow-up | Paired width-32 parent-fitting policies: [v3-followup-depth.png](graphs/v3-followup-depth.png)
- V3 follow-up | Paired width-32 parent-fitting policies: [v3-followup-parameters.png](graphs/v3-followup-parameters.png)
- V3 follow-up | Seed mean and standard error: [v3-followup-repeats.png](graphs/v3-followup-repeats.png)
- V4 | Frozen random CNN, fixed depth 1 / width: [v4-primary-width.png](graphs/v4-primary-width.png)
- V4 | Frozen random CNN, fixed depth 1 / parameters: [v4-primary-parameters.png](graphs/v4-primary-parameters.png)
- V4 | Random features, width 16 / depth: [v4-w16-depth.png](graphs/v4-w16-depth.png)
- V4 | Random features, width 16 / parameters: [v4-w16-parameters.png](graphs/v4-w16-parameters.png)
- V4 | Random features, width 32 / depth: [v4-w32-depth.png](graphs/v4-w32-depth.png)
- V4 | Random features, width 32 / parameters: [v4-w32-parameters.png](graphs/v4-w32-parameters.png)
- V4 | Random features, width 64 / depth: [v4-w64-depth.png](graphs/v4-w64-depth.png)
- V4 | Random features, width 64 / parameters: [v4-w64-parameters.png](graphs/v4-w64-parameters.png)
- V4 | Random features, width 128 / depth: [v4-w128-depth.png](graphs/v4-w128-depth.png)
- V4 | Random features, width 128 / parameters: [v4-w128-parameters.png](graphs/v4-w128-parameters.png)
- V4 | Random features, width 256 / depth: [v4-w256-depth.png](graphs/v4-w256-depth.png)
- V4 | Random features, width 256 / parameters: [v4-w256-parameters.png](graphs/v4-w256-parameters.png)
- V4 | Compare widths at fixed maximum depth: [overview-v4-depth-slices.png](graphs/overview-v4-depth-slices.png)
- V4 | Available correction-seed repetitions: [v4-repeats.png](graphs/v4-repeats.png)
- Most relevant hints | Preliminary, not confirmed double descent: [strongest-hints.png](graphs/strongest-hints.png)