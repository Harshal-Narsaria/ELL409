# ELL409 Version 4: frozen random CNN features

The CNN supplies features without learning labels. Three convolution/ReLU/pooling
blocks (16, 32, 64 channels) and a 2×2 spatial grid give 256 features per 32×32 RGB
image. CNN weights are initialized once with seed 409 and remain frozen. There
is no CNN classification head, training loss or optimizer. A feature extractor
alone has no classification accuracy; report the small root classifier baseline.

The original dataset manifests and training-only image normalization are reused.
Feature means/scales are calculated on training images only. No learned CNN
weights from previous versions are reused. Exact feature collisions with
conflicting training labels are checked before interpreting fit limits. Features
and the extractor are cached, so the image CNN is evaluated once per image during
extraction and once per image at deployment, shared across the entire forest.

## Controlled primary experiment

Train a width-8 MLP root on the 256 features once per seed, then freeze that base
network across all correction widths and depths. Roots are binary for Cats vs
Dogs and ten one-versus-rest classifiers for CIFAR-10, with argmax root scores.
Evaluate the root-only baseline separately. Primary correction width is swept
over 4, 8, 16, 32, 64, 128, 256, 512 at a fixed maximum depth of one. Each child
learns the reference's masked positive/negative correction task. Since root base
predictions are fixed, primary task masks and required child positions do not
change with width. Parent corrections feed upward with nonnegative positive
strength and nonpositive negative strength. The verified positive-margin LP from
the width-32 follow-up is used when feasible, otherwise the existing BCE optimizer.

Roots/children train for 200 epochs without augmentation, dropout, weight decay,
label smoothing or artificial label noise. Node selection uses classification
errors first and BCE second. Checkpoints save optimizer and random-generator
states. Increasing width is a new training run; increasing depth reuses existing
base networks on unchanged tasks. Existing nodes take priority when caps bind.

If no primary width attains zero full-training classification error, a separately
labelled adaptive-tree study uses widths 16,32,64,128,256 and depth limits 2,4,6,10.
The trigger uses training results only. It is not pooled with the fixed-topology
primary curve. Maximum per-tree nodes are 127 with a total tree budget of 30M
parameters. Natural saturation is recorded; unchanged depth limits do not imply
additional capacity. Convergence flags identify continuing node-loss decreases;
they do not prove convergence or guarantee that remaining error is a capacity
limit. Undertrained configurations cannot substantiate double descent.

Representative configurations below/at/above the first observed zero-error
capacity are repeated with seeds 410 and 411. If interpolation is absent, repeat
low/middle/high capacities. This is conditional on one fixed random CNN, not an
extractor-seed robustness study. A missing capacity above interpolation is
reported explicitly. CNN performance and double descent are not guaranteed.

## Measurements and evidence

Save training/validation/test accuracy, losses, confusion matrices, positive
recall/negative accuracy per binary root, histories, actual depth, node counts,
active nonzero-edge capacity and complete deployed parameter count. Count the
CNN once. Primary and deeper plots have separate files. Star markers indicate
zero training errors; seed summaries report mean and standard error where repeats
exist. Deployment is the smallest primary-seed model reaching 99.5% training
accuracy, or the best training fit if none does. No model is selected by test
accuracy. Dataset versions/splits are inherited from the original manifests.

Test curves are exploratory repeated measurements on splits already inspected
in earlier studies; the new feature choice followed those observations. A clear
rise and second decline near interpolation, with convergence and repeat checks,
would be evidence under this setup, not a guaranteed outcome or a fresh untouched
test benchmark. Do not infer double descent from a tiny dip, a training/test gap,
or zero training error alone. No new final assignment report is substituted here.

## Running and resuming

Run from this folder:

```powershell
..\.venv\Scripts\python.exe -B -u queue_random_cnn.py
```

This finite queue waits for the current width-32 follow-up and starts this study
afterward. If interrupted, the same command resumes the prior job if needed,
then this study. It uses OS file locks to prevent duplicate workers. Keep the
laptop awake and plugged in. It is not a Windows restart service or recurring
automation. The queue is safe to leave running while the earlier worker finishes.

For a direct run when no other trainer is active:

```powershell
..\.venv\Scripts\python.exe -B -u random_cnn_study.py
```

`config.json` declares the experiment; `random_cnn_study.py` contains features,
training, evaluation and deployment; `queue_random_cnn.py` manages execution order;
`tests/` checks frozen weights, train-only statistics, root reuse, saved prediction
equivalence and queue order. Existing local dependencies and helpers from Versions
1–3 are reused read-only. Copy all four code directories for cloud execution.

`runs/random-cnn/` contains configs, hashes, checkpoints, feature caches and live
progress. `results/random-cnn/<dataset>/` contains measurements, plots, repeat
summaries and the chosen deployment. Small smoke results are debugging evidence,
not results for the full assignment. All previous study results are preserved
and their hashes verified on completion.
