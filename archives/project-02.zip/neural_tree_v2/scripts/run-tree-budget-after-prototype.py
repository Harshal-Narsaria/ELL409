"""Queue one finite GPU study after the prototype releases its OS-held lock."""
from pathlib import Path
import os
import sys
import time

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
os.chdir(PROJECT)

from v2_tree.common import study_lock, write_json


def main():
    study = PROJECT / "runs/tree-budget-v2"
    with study_lock(study / "queue.lock"):
        write_json(study / "progress.json", {
            "status": "queued", "pid": os.getpid(), "updated_unix": time.time(),
            "waiting_for": "runs/image-tree-v2/runner.lock", "uses_test_data": False})
        print("Fixed-root tree study queued; waiting for the prototype to release the GPU.", flush=True)
        while True:
            try:
                with study_lock(PROJECT / "runs/image-tree-v2/runner.lock"):
                    pass
            except RuntimeError:
                time.sleep(15)
                continue
            break
        import torch
        from v2_tree.study import study_main
        if not torch.cuda.is_available():
            write_json(study / "progress.json", {"status": "failed", "error": "CUDA unavailable", "updated_unix": time.time()})
            raise RuntimeError("CUDA unavailable; rerun the queue command when the GPU is available.")
        print("Prototype released its lock. Starting the fixed-root tree study.", flush=True)
        study_main(PROJECT.parent / "neural_tree", study, PROJECT / "results/tree-budget-v2",
                   PROJECT / "configs/tree-budget-study.json", torch.device("cuda"), stage="all")


if __name__ == "__main__":
    main()
