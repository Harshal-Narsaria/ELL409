param([ValidateSet('main','sweep','all')][string]$Stage = 'all')
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectPath
$pythonPath = Join-Path (Split-Path -Parent $projectPath) '.venv\Scripts\python.exe'
New-Item -ItemType Directory -Force 'runs\tree-budget-v2' | Out-Null
& $pythonPath -B -u -m v2_tree run --config configs/tree-budget-study.json --study-dir runs/tree-budget-v2 --output-dir results/tree-budget-v2 --device cuda --stage $Stage
if ($LASTEXITCODE -ne 0) { throw "Version 2 training stopped. Inspect runs/tree-budget-v2/progress.json; rerun this script to resume." }
