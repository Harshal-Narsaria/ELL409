# Version 2 results

Separate exploratory study: learn from original image pixels; no pretrained CNN, shared supervised trunk, augmentation, dropout, or added label noise. Preserve all original results. Use train/validation only until an explicit candidate lock. Improvement and double descent are hypotheses, not required outcomes.

All accuracies below use the original labels. Test evaluation is pending an explicit candidate lock.

| Dataset | Model | Train % | Validation % | Parameters | Nodes / CNN nodes | Root-to-tree train gain (pp) |
|---|---|---:|---:|---:|---:|---:|
| cats_vs_dogs | capacity-pixel-tree-w16 | 99.764 | 63.758 | 245940 | 5 / 0 | 6.777 |
| cats_vs_dogs | capacity-pixel-tree-w32 | 99.962 | 64.488 | 393488 | 4 / 0 | 0.688 |
| cats_vs_dogs | capacity-pixel-tree-w4 | 88.365 | 63.457 | 86100 | 7 / 0 | 12.092 |
| cats_vs_dogs | capacity-pixel-tree-w64 | 100.000 | 65.907 | 393480 | 2 / 0 | 0.005 |
| cats_vs_dogs | capacity-pixel-tree-w8 | 96.958 | 61.995 | 172172 | 7 / 0 | 13.263 |
| cats_vs_dogs | cnn-only-roots | 85.436 | 80.138 | 5524 | 1 / 1 | 0.000 |
| cats_vs_dogs | fit-hybrid-w32 | 100.000 | 64.531 | 98372 | 1 / 0 | 0.000 |
| cats_vs_dogs | main-hybrid-w16 | 98.323 | 63.500 | 502928 | 12 / 2 | 5.336 |
| cats_vs_dogs | main-pixel_tree-w16 | 99.780 | 63.758 | 344316 | 7 / 0 | 6.793 |
| cats_vs_dogs | narrower-selected-architecture | 99.839 | 63.844 | 207800 | 6 / 2 | 1.155 |
| cats_vs_dogs | parameter-matched-mlp-roots | 100.000 | 64.531 | 98372 | 1 / 0 | 0.000 |
| cats_vs_dogs | pruned | 100.000 | 64.531 | 98372 | 1 / 0 | 0.000 |
| cifar10 | capacity-pixel-tree-w16 | 98.913 | 46.200 | 2803716 | 57 / 0 | 6.624 |
| cifar10 | capacity-pixel-tree-w32 | 99.876 | 49.700 | 3541392 | 36 / 0 | 0.789 |
| cifar10 | capacity-pixel-tree-w4 | 74.767 | 40.440 | 811800 | 66 / 0 | 16.918 |
| cifar10 | capacity-pixel-tree-w64 | 99.996 | 51.980 | 4328280 | 22 / 0 | 0.058 |
| cifar10 | capacity-pixel-tree-w8 | 94.996 | 44.600 | 1672528 | 68 / 0 | 18.393 |
| cifar10 | cnn-only-roots | 78.862 | 69.660 | 55240 | 10 / 10 | 0.000 |
| cifar10 | fit-hybrid-w32 | 99.989 | 49.880 | 1838260 | 25 / 7 | 0.036 |
| cifar10 | fit-pixel_tree-w32 | 99.989 | 49.900 | 1672324 | 17 / 0 | 0.036 |
| cifar10 | main-hybrid-w16 | 98.558 | 50.360 | 4340648 | 106 / 20 | 6.269 |
| cifar10 | main-pixel_tree-w16 | 99.138 | 46.280 | 3885852 | 79 / 0 | 6.849 |
| cifar10 | narrower-selected-architecture | 99.791 | 45.200 | 1770768 | 36 / 0 | 1.536 |
| cifar10 | parameter-matched-mlp-roots | 99.998 | 50.100 | 1660000 | 10 / 0 | 0.000 |
| cifar10 | pruned | 99.953 | 49.920 | 983720 | 10 / 0 | 0.000 |

The root ablation uses identical root weights and removes correction children. Parameter-matched MLP controls distinguish tree structure from additional capacity. CNN-only roots use the same small CNN family and node budget, not the earlier shared CNN.

No gain or double-descent result is assumed. Adaptive child growth changes topology across widths; nominal width is the controlled factor, and actual model size is also recorded. One seed provides exploratory evidence only. Ongoing loss reduction is flagged; a fixed epoch budget is not a convergence proof.

Both datasets use 32x32 inputs. The old Cats-vs-Dogs experiment used 128x128; compare Version 2 architectures within Version 2, and disclose this resolution difference when comparing versions.

Pruning uses a cumulative validation tolerance of 0.5 percentage points relative to the original model. Training accuracy after pruning is recorded even if interpolation is lost.
