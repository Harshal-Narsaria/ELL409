# Version 2 results

Separate original-label, exploratory tree-budget study. Root MLP width 4 and 120 training epochs remain fixed while correction networks supply additional capacity. Hybrid CNNs are independently trained only at depth 1. No shared trained trunk, pretrained weights, augmentation or added label noise. Unrestricted parameter-matched MLP and CNN-only controls test whether the tree provides value beyond extra capacity. Both validation-preserving and training-fit-preserving pruning are reported. Preserve Version 1 and broader-root Version 2 trials. Improvement and double descent are hypotheses, not required outcomes.

Tree roots have a fixed width of 4 and 120 epochs. Reported width varies correction-node capacity. CNN-only and parameter-matched controls are unrestricted.

All accuracies below use the original labels. Test evaluation is pending an explicit candidate lock.

| Dataset | Model | Train % | Validation % | Parameters | Nodes / CNN nodes | Root-to-tree train gain (pp) |
|---|---|---:|---:|---:|---:|---:|
| cats_vs_dogs | capacity-pixel-tree-w16 | 97.910 | 63.672 | 307428 | 7 / 0 | 21.636 |
| cats_vs_dogs | capacity-pixel-tree-w32 | 98.350 | 63.672 | 504160 | 6 / 0 | 22.077 |
| cats_vs_dogs | capacity-pixel-tree-w4 | 88.365 | 63.457 | 86100 | 7 / 0 | 12.092 |
| cats_vs_dogs | capacity-pixel-tree-w64 | 98.452 | 63.844 | 405780 | 3 / 0 | 22.179 |
| cats_vs_dogs | capacity-pixel-tree-w8 | 94.873 | 63.500 | 159876 | 7 / 0 | 18.600 |
| cats_vs_dogs | cnn-only-roots | 85.436 | 80.138 | 5524 | 1 / 1 | 0.000 |
| cats_vs_dogs | fit-hybrid-w32 | 97.286 | 72.657 | 425092 | 7 / 2 | 21.012 |
| cats_vs_dogs | fit-pixel_tree-w32 | 98.425 | 63.371 | 209044 | 3 / 0 | 22.152 |
| cats_vs_dogs | main-hybrid-w16 | 95.378 | 69.390 | 515228 | 13 / 2 | 19.105 |
| cats_vs_dogs | main-pixel_tree-w16 | 97.990 | 63.887 | 454992 | 10 / 0 | 21.716 |
| cats_vs_dogs | narrower-selected-architecture | 98.597 | 63.328 | 209052 | 5 / 0 | 22.324 |
| cats_vs_dogs | parameter-matched-mlp-roots | 100.000 | 66.122 | 209036 | 1 / 0 | 0.000 |
| cats_vs_dogs | pruned | 84.469 | 62.984 | 110672 | 2 / 0 | 0.000 |
| cifar10 | capacity-pixel-tree-w16 | 96.438 | 44.340 | 2533212 | 59 / 0 | 38.589 |
| cifar10 | capacity-pixel-tree-w32 | 98.320 | 45.680 | 4254624 | 52 / 0 | 40.471 |
| cifar10 | capacity-pixel-tree-w4 | 74.767 | 40.440 | 811800 | 66 / 0 | 16.918 |
| cifar10 | capacity-pixel-tree-w64 | 98.771 | 46.900 | 6025200 | 40 / 0 | 40.922 |
| cifar10 | capacity-pixel-tree-w8 | 89.038 | 42.340 | 1524972 | 67 / 0 | 31.189 |
| cifar10 | cnn-only-roots | 78.862 | 69.660 | 55240 | 10 / 10 | 0.000 |
| cifar10 | fit-hybrid-w32 | 97.500 | 60.580 | 4044524 | 67 / 19 | 39.651 |
| cifar10 | fit-pixel_tree-w32 | 98.729 | 45.400 | 2680672 | 36 / 0 | 40.880 |
| cifar10 | main-hybrid-w16 | 94.971 | 58.280 | 4408936 | 114 / 19 | 37.122 |
| cifar10 | main-pixel_tree-w16 | 97.116 | 44.260 | 4254792 | 94 / 0 | 39.267 |
| cifar10 | narrower-selected-architecture | 98.371 | 43.280 | 2238084 | 53 / 0 | 40.522 |
| cifar10 | parameter-matched-mlp-roots | 99.998 | 51.980 | 2674420 | 10 / 0 | 0.000 |
| cifar10 | pruned | 94.009 | 45.240 | 1106720 | 20 / 0 | 0.000 |

The root ablation uses identical root weights and removes correction children. Parameter-matched MLP controls distinguish tree structure from additional capacity. CNN-only roots use the same small CNN family and node budget, not the earlier shared CNN.

No gain or double-descent result is assumed. Adaptive child growth changes topology across widths; nominal width is the controlled factor, and actual model size is also recorded. One seed provides exploratory evidence only. Ongoing loss reduction is flagged; a fixed epoch budget is not a convergence proof.

Both datasets use 32x32 inputs. The old Cats-vs-Dogs experiment used 128x128; compare Version 2 architectures within Version 2, and disclose this resolution difference when comparing versions.

Pruning uses a cumulative validation tolerance of 0.5 percentage points relative to the original model. Training accuracy after pruning is recorded even if interpolation is lost.

The pruned-retain-fit condition additionally rejects removals that reduce training accuracy below 99.5%, when a near-fitting source was found.
