# Width-32 CIFAR-10 follow-up

This is a separate exploratory experiment requested after inspecting the original
width-32 test curve. That curve's late decrease was small; it is not evidence of
double descent on its own. Existing studies, checkpoints and plots are preserved.

The frozen CNN, dataset splits, feature normalization and 200-epoch node training
schedule stay identical to Version 3. Width remains 32. The primary seed is 409;
two additional correction-network seeds (410, 411) repeat depths 0, 10 and 20.
These seeds share the same frozen CNN, so their variation does not measure CNN
training uncertainty. All settings are declared in `width32-followup.json` before
new held-out results are inspected.

Two arms are kept separate:

1. **Original:** reuse completed depths 0–10 and their learned node bases, then
   extend maximum depth to 11, 12, 14, 16 and 20 using the original parent fitting.
2. **Classification refit:** reuse the same learned node bases and compare all
   declared depths using a parent fitting improvement. The old linear program
   requires margin one with a fixed base coefficient; two already-correct scores
   +0.01 and -0.01 with inactive children cannot both be moved to margins ±1 by
   a bias. The new program maximizes a common positive margin up to one and
   accepts smaller feasible margins. It then minimizes the sum of nonnegative
   child strengths at half that feasible margin, verifying actual floating-point
   predictions on training data. It falls back to the original optimizer when
   perfect classification is infeasible. Child signs and network architecture
   are unchanged. This is an optimization comparison, not an extra-capacity claim.

Base tasks depend on original base predictions, so both arms share the exact
same correction-network weights at each path. Source checkpoints are copied
into a new run directory; new descendants are trained there. Each node retains
the original resumable optimizer and RNG checkpoints. Fitted forests and model
choices use training errors, with loss as a tie-breaker. Test scores never drive
node growth or model selection. Deployment is selected separately per arm by
the smallest primary-seed model meeting 99.5% training accuracy, or the best
training fit if that threshold is missed.

When all leaf base tasks fit perfectly and the node cap does not bind, deeper
limits cannot add error-driven children. Later stages reuse the saturated forest
and are explicitly marked. They do not count as larger models or establish
post-interpolation double descent. At zero training error the same growth rule
may also stop adding capacity; observing interpolation alone is insufficient.
Internal convergence flags remain available in the saved measurements.

Outputs: `results/width32-followup/cifar10/` contains measurements, plots,
interpolation/plateau observations and separate deployment checkpoints.
`runs/width32-followup/progress.json` records status. `definition.json` records
settings, code and source-checkpoint hashes. Source hashes are checked again
on completion. Validation and repeatedly accessed test curves are both shown;
the test curve is explicitly exploratory because it motivated this follow-up.
A confirmatory claim would require an independent holdout and further controlled
capacity experiments; no curve shape is guaranteed.

Run or resume from this folder:

```powershell
..\.venv\Scripts\python.exe -B -u width32_followup.py
```

One finite worker holds a lock to prevent duplicates. It resumes from completed
stages or the last node-training epoch. The laptop must stay awake and powered
while it runs; this command does not install an automatic restart service.
