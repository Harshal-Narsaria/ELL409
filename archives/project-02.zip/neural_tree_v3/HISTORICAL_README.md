# ELL409 Version 3: frozen CNN near 80% training accuracy

This study implements a CNN deliberately stopped before it memorizes the training set, followed by increasingly deep neural error-correction trees. Versions 1 and 2, their results, and their running processes remain unchanged. Existing trusted architecture/checkpoint/training helpers are imported read-only; no previous learned weights are reused.

## Procedure

1. Reuse the exact original training, validation, and test splits. Both datasets use 32x32 RGB images; normalization uses training pixels only. Cats vs Dogs resolution differs from Version 1's 128x128 inputs.
2. Train the original compact six-convolution CNN from scratch. Evaluate the complete training split after every epoch in evaluation mode. Stop at the first epoch with training accuracy at least 80%, with a 60-epoch failure limit. Record the actual accuracy, which may overshoot 80%. Neither validation nor test accuracy selects this checkpoint. A failure to reach the threshold is reported, not silently renamed an 80% model.
3. Freeze both the convolutional trunk and its classification head. Use its original decisions as the tree roots; do not train replacement root MLPs that might solve everything themselves. For CIFAR-10, winner-versus-strongest-alternative logits yield ten binary root scores while preserving CNN argmax predictions. For Cats vs Dogs, use dog-logit minus cat-logit.
4. Cache the CNN's 128 features and frozen root scores. Normalize features with training-only statistics. Correction children receive the features; frozen CNN scores remain accessible only to root score modules. One shared CNN is included in deployment and counted once.
5. Use the reference's positive/negative correction targets and don't-care masks. Children are feature MLPs with nonnegative upward positive corrections and nonpositive upward negative corrections. Existing base networks and their correction tasks are reused when depth increases; correction strengths are refitted because children now produce different corrected predictions.
6. Follow the predeclared width grid 32,64,128,256 and depth grid 0 through 10. Root depth is 0. Train child bases for 200 epochs, correction strengths for 150 epochs plus the existing signed margin-feasibility check. Base models are selected by training errors, then training loss. No child stopping rule uses held-out accuracy.
7. Record full training, validation and test classification error and loss after every complete forest stage. Save forest checkpoints, task histories and the frozen CNN checkpoint, optimizer states and RNG states. Interrupted node training resumes at an epoch boundary. Completed stages are reused.
8. Repeat representative depths with two additional correction-training seeds, using the same CNN. Choose those depths using the first zero-training-error stage only; if interpolation is absent, repeat low/middle/high declared depths. This is a limited reproducibility check over three correction seeds, not a full-grid confidence interval or an independent CNN-seed study. Export the smallest primary-seed model reaching the 99.5% training target as a complete image classifier; if none fits, export the best training-fit model and disclose the shortfall. Test scores never select that model.

The maximum is 2,047 nodes per binary tree, with a total correction-parameter allocation budget of 30 million across the forest, to respect this computer's memory. Budget caps and actual reached depth are recorded. Existing nodes take priority over new growth when a node budget binds. A deeper maximum does not necessarily create more nodes: no child is created for an already perfect base task. Report parameter plateaus rather than treating them as larger models.

## Interpreting the experiment

An 80% training accuracy alone does not prove that the CNN has not overfit: examine its validation/test gap too. CNN early stopping here is a deliberate feature/root limitation. The correction stage uses no dropout, weight decay, label smoothing, stochastic augmentation, or artificial label noise. Normalization is retained for numerical conditioning. Optimization itself still has implicit biases; removing explicit regularization does not guarantee double descent.

Training improvement shows correction-tree utility. A large train/test gap shows overfitting. Double descent requires a credible held-out error rise and later decline associated with interpolation; reaching 100% training accuracy alone is insufficient. The experiment continues through the full declared depth grid even after interpolation, but naturally saturated trees may stop adding parameters. Training can fluctuate as child outputs and parent refits change; monotonic accuracy is not assumed. Loss-decrease flags identify potentially undertrained nodes. Width/seed differences and adaptive topology must be disclosed.

The user explicitly requested repeated **test** evaluation for these curves. Test results never train nodes, alter CNN stopping, select depth/width, or choose seed repetitions. Nevertheless these are exploratory repeated measurements on test splits already used in Version 1. They must not be described as a fresh untouched final benchmark, and a future test-informed design would need a new independent holdout for a confirmatory claim.

## Run and resume

From this folder, using the existing workspace environment:

```powershell
..\.venv\Scripts\python.exe -B -u queue-study.py
```

The queue finishes the active Version 2 prototype, then runs Version 3 before the waiting Version 2 fixed-root study. This priority was requested on 2026-10-09. The two old waiting dispatchers were stopped and replaced with this single dispatcher; the active training process and completed results were preserved. The fixed-root study starts after Version 3 completes. This brings Version 3 results forward without reducing the total declared computation. It is a finite process, not a recurring automation or a Windows restart service. Keep the laptop awake and plugged in. Do not launch another worker for either queued study while this dispatcher is active. Use this queue command to resume the prioritized sequence after an interruption.

To start/resume directly when the GPU is free:

```powershell
..\.venv\Scripts\python.exe -B -u study.py
```

Use the same config and output directory to resume. A frozen protocol identity records code hashes, configuration and manifests. Changed settings require a new run directory. Do not put outputs inside Version 1. For another computer, copy all three code folders and install Version 2's recorded environment.

## Files

* `config.json`: declared stopping rule, depth/width sequence, parameter budget and test policy.
* `study.py`: CNN stopping/freezing, feature caching, progressive correction training, evaluation and exports.
* `queue-study.py`: waits for existing jobs and starts this study once.
* `tests/test_study.py`: freezing, score equivalence, growth/resume and deployment checks.
* `runs/cnn80-depth/`: generated frozen CNNs, cached features, stage checkpoints, progress and protocol definitions.
* `results/cnn80-depth/<dataset>/`: generated measurements CSV/JSON, CNN baseline, parameter-error plot and interpolation observations.

These measurements are not submission-ready results until full runs and convergence checks finish. A new final PDF is not generated or substituted for the existing report by this study.
