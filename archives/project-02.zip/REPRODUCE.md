# Reproducing the work

Extract both project ZIPs into the same folder to see the code. Raw datasets, virtual environments, feature caches and every intermediate optimizer checkpoint are omitted from the upload. The original local study folders retain them. Selected deployment weights and scientific evidence are archived.

## Setup

Use Python 3.12. Install an appropriate matching PyTorch/torchvision pair from https://pytorch.org/get-started/locally/ for your machine, then run these commands from the repository root:

```powershell
python -m pip install -r requirements.txt
python -m pip install -e ./neural_tree -e ./neural_tree_v2
```

The exact historical environment is in both `requirements-lock.txt` files. Hardware changes can affect numerical results. The data and held-out policies in the study configs must stay fixed.

## Check the implementation

```powershell
python -B -m pytest neural_tree/tests neural_tree_v2/tests neural_tree_v3/tests neural_tree_v4/tests --import-mode=importlib -q -p no:cacheprovider
```

Tests check correction masks and signs, recursive save/load, fixed roots, checkpoint recovery, frozen CNNs and the fitting refinement. Debugging tests are not full-dataset results.

## Prepare the data

Run these commands from `neural_tree/`, with seed 409:

```powershell
python -m ell409_tree prepare cifar10 --data-dir data --seed 409
python -m pip install -e ".[cats]"
python -m ell409_tree prepare cats_vs_dogs --data-dir data --seed 409
```

The second dataset preparation uses TensorFlow only for data preparation. The saved split manifests in `split-manifests/` are the experiment reference. Compare newly generated manifests with them before reproducing training. Do not copy a manifest into an empty data directory before preparation: the preparer treats an existing manifest as completed and would skip image export. The original Cats export is 128 x 128; later versions deliberately resize it to 32 x 32. Later studies read `neural_tree/data/<dataset>/manifest.json` and their associated images.

## Train the original version

From `neural_tree/`:

```powershell
python -m ell409_tree run --manifest data/cifar10/manifest.json --config configs/cifar10.json --run-dir runs/cifar10 --device cuda --stage all --finalize
python -m ell409_tree run --manifest data/cats_vs_dogs/manifest.json --config configs/cats_vs_dogs.json --run-dir runs/cats_vs_dogs --device cuda --stage all --finalize
python -m ell409_tree dense-study --device cuda
python -m ell409_tree epoch-history --run-dir runs/cifar10 --device cuda --epochs 300
python -m ell409_tree epoch-history --run-dir runs/cats_vs_dogs --device cuda --epochs 300
```

Use `--device cpu` if no compatible GPU exists, with longer runtimes. Training commands are expensive; reading packaged evidence requires no training.

## V2-V4

Run each command inside its named folder, sequentially:

```powershell
# neural_tree_v2: retained prototype, then fixed-root study
python -m v2_tree run --config configs/study.json --study-dir runs/image-tree-v2 --output-dir results/image-tree-v2 --original ../neural_tree --device cuda --stage all
python -m v2_tree run --config configs/tree-budget-study.json --study-dir runs/tree-budget-v2 --output-dir results/tree-budget-v2 --original ../neural_tree --device cuda --stage all
# neural_tree_v3: partially trained CNN, then CIFAR parent-refit follow-up
python study.py --device cuda
python width32_followup.py --device cuda
# neural_tree_v4: frozen random CNN
python random_cnn_study.py --device cuda
```

The same config and output folder resumes an interrupted run. Changed configs require new run directories. Do not launch duplicate workers. A sleeping laptop cannot train; no automatic startup service is installed.

## Read evidence and rebuild the report

Both project ZIPs restore original relative paths, including measurements, node panels and the graph atlas. Run `python tools/verify_submission.py` after extraction. Run `python tools/plot_saved_results.py` for historical plots, `python tools/plot_concise_capacity.py` for the final noise plots and `python tools/build_report.py` for the final report. The latter accepts --name and --student-id. Visually inspect a rebuilt PDF before submitting it.

## Noise study

Restore archives with the provided tool. Version 5 keeps the existing original train/validation/test membership and frozen V3 CNN80 features. Prepare the data and V3 feature cache using the original instructions before running `python neural_tree_v5/noise_study.py`. The first study uses config.json. Run `python neural_tree_v5/noise_followup.py` for the longer-budget follow-up; restore the supplemental cats-bracket-config.json and use --config, --run-dir and --output to run that separate study. Missing original optimizer files cause a fresh same-budget fit; exact matching locally retained checkpoints can continue. The selected image deployments include the CNN weights and normalization, and can be loaded with neural_tree_v5/deploy_noise.py without raw data. Test figures remain exploratory on previously used splits.
