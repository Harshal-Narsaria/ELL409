# ELL409: image-level correction trees, Version 2

This is a separate experiment beside `../neural_tree`. The completed original CNN-feature experiments, dense sweep, PDF, and upload folders remain there. Version 2 does not import their model or training implementation and does not reuse any learned weights. It reuses the prepared datasets and fixed splits.

The question is whether a correction tree makes a larger contribution when a strong shared supervised CNN no longer solves most of the task before tree training begins. A gain in training fit, a gain in validation accuracy, and double descent are three different outcomes. None is assumed in advance. Lower generalization or greater parameter cost than Version 1 is possible and must be reported.

There are two separately recorded Version 2 studies. The **broader-root prototype** (`configs/study.json`, `runs/image-tree-v2`) showed that a wider root-only pixel MLP can also fit Cats vs Dogs perfectly. Its trials are retained. The **primary fixed-root study** (`configs/tree-budget-study.json`, `runs/tree-budget-v2`) therefore fixes each tree's root at four hidden units and 120 epochs. Increasing width or the fitting budget expands the correction networks; the root budget stays fixed. This isolates the contribution of correction children under a declared root budget. It does not prove that a tree outperforms every standalone network. The CNN-only and parameter-matched MLP controls remain unrestricted.

## Architecture

Both datasets use 32x32 RGB images. Normalization is computed from the Version 2 training pixels only. Each image is processed independently; collections of training examples determine a node's learning task, rather than becoming input objects at inference time.

| Version 2 condition | Root | First correction children | Deeper correction nodes |
|---|---|---|---|
| Pixel tree | Small pixel MLP | Independent pixel MLPs | Independent pixel MLPs |
| Selective-CNN hybrid | Small pixel MLP | Independent small CNNs, trained on correction targets | Independent pixel MLPs |
| Root ablation | Identical learned root weights | Removed | Removed |
| CNN-only control | Small CNN at each classification root | None | None |
| Parameter-matched control | Wider pixel MLP at each root | None | None |

There is **no common trained trunk**. All networks are trained from scratch on the examples assigned to their node. MLPs flatten the same input image and use `3072 -> width -> 1`. Each local CNN uses two convolutions with 8 and 16 channels, ReLU, pooling, a 4x4 pooled spatial representation, and a small scalar head. The main correction width is 16; the fixed-root study uses root width 4. This is not the six-convolution CNN from Version 1.

The reference's upward error correction is retained:

`score = base_score(image) + alpha * child_A_prediction - beta * child_B_prediction + offset`

Here `alpha,beta >= 0`; child predictions are hard, recursively corrected binary outputs. A corrects false negatives; B corrects false positives. The reference's "don't care" examples are excluded from the corresponding child loss. A child that cannot fit its own correction task receives correction children itself. This is not a routing tree or a majority-voting ensemble.

Cats vs Dogs uses one binary tree; CIFAR-10 uses ten one-versus-rest trees and argmax of their final scores. Improving individual binary error counts does not mathematically guarantee better final multiclass argmax accuracy; both are measured.

## Declared experiments

Each study's configuration records its complete protocol before that study begins. Both use original labels, no added noise, no augmentation, no dropout, and no weight decay. The following describes their common procedure; the primary study additionally fixes the MLP root width/epochs as described above.

1. Train the pixel tree and selective-CNN tree at width 16, depth at most 3 (root depth 0), and at most 15 nodes per binary tree. MLPs receive 120 epochs; CNNs receive 60 epochs. Correction strengths receive 150 epochs plus a signed margin-feasibility check. Best base checkpoints are chosen by training classification errors, then loss.
2. If a condition does not reach 99.5% final training accuracy, make a separate width-32 fitting attempt with depth at most 4, at most 31 nodes, 240 MLP epochs and 90 CNN epochs. The earlier attempt remains visible. This is a bounded fitting attempt, not a guarantee of perfect memorization; if it still misses the target, the failure is recorded.
3. Train CNN-only roots on the complete training split using the same local CNN family and its declared epoch budget.
4. For each trained tree, evaluate identical roots with all corrections removed. This directly measures the correction mechanism's contribution. Compare the selected tree with a wider root-only MLP whose parameter count is as close as possible to the tree's total. Report the small rounding difference.
5. Choose the smallest model meeting the training target, otherwise the candidate with best training accuracy. Prune correction subtrees using a cumulative 0.5-percentage-point validation tolerance relative to the original model. Record training accuracy after pruning. Retrain the selected architecture at half its hidden width.
6. Show strong base activations and assigned-positive examples, full-training activation frequencies/class composition, MLP gradient maps or CNN Grad-CAM, and 4x4 occlusion maps for a root and correction nodes. These are response/attribution maps, not evidence of a universal semantic detector.
7. The `sweep` stage studies pixel trees at widths 4, 8, 16, 32, 64 with a common depth/node limit and optimizer/epoch budget. Plot train/validation error and loss, with root-only validation comparisons. Mark the first observed zero training error. Actual active parameters and node counts are recorded. Adaptive growth means this is an exploratory width study, not an experiment with constant active topology. One seed and remaining optimization flags limit strong double-descent claims.

In the primary study, step 2 preserves root width 4 and root epochs 120 while widening and training the correction nodes further. Step 5 reports two pruning results: validation tolerance alone, and the same tolerance with training accuracy also required to stay at least 99.5%. Narrower retraining halves correction widths while preserving the root. Step 7 varies correction widths only. The parameter-matched root-only MLP receives its matched width and the selected condition's full MLP epoch budget, so the control can use its additional capacity.

The default script runs the main experiments and capacity stage sequentially. No test image is loaded during either stage. Validation is used for pruning; test evaluation requires a later explicit candidate lock. The original test partition has already been used in Version 1, so later Version 2 evaluation must be described as exploratory reuse, not a new unseen benchmark.

## Run on this computer

Open a terminal in this folder. The existing GPU environment is `../.venv`:

```powershell
..\.venv\Scripts\python.exe -B -m pytest -q -p no:cacheprovider
..\.venv\Scripts\python.exe -B -u -m v2_tree smoke --device cuda
.\scripts\run-study.ps1 -Stage all
```

The launcher above runs/resumes the primary fixed-root study. To run the retained prototype explicitly, use `python -m v2_tree run --config configs/study.json --study-dir runs/image-tree-v2 --output-dir results/image-tree-v2 --device cuda --stage all`. On another computer, install this project's dependencies, prepare the original datasets using Version 1's preparation instructions, and pass their project folder with `--original`. Do not put Version 2 outputs inside Version 1.

To queue the primary study after an already-running prototype, use `..\.venv\Scripts\python.exe -B -u scripts/run-tree-budget-after-prototype.py`. The finite queue waits for the prototype's operating-system lock before starting GPU work. It does not install a recurring automation or restart service. Do not launch the primary launcher again while that queue is active.

On 2026-10-09 the user prioritized the separate CNN-at-80% Version 3 study. The active dispatcher is now `../neural_tree_v3/queue-study.py`: it finishes the current prototype, runs Version 3, then runs this fixed-root study. Use that dispatcher to resume the current sequence. Do not start the old queue or this study's direct launcher while the prioritized dispatcher owns this study's queue lock. The experiment configuration and completed results are unchanged.

Interrupted runs resume from saved node checkpoints and skip completed nodes/models. Epoch checkpoints include optimizer and Python/NumPy/Torch/CUDA random states. An OS-held lock prevents two runners from writing the same study. The model configuration, code hashes, dataset identities, and pixel fingerprints are frozen; incompatible resumes require a new study directory. Numerical reproducibility across hardware is not guaranteed.

Windows can temporarily deny atomic replacement while a status reader has the file open. File commits retry these sharing violations; progress updates are throttled and observational logging cannot abort training. An initial run exposed this issue and was resumed after a documented I/O-only compatibility repair. The study keeps its original definition and records the two changed helper-module hashes; model mathematics, preprocessing, hyperparameters and checkpoint identities were preserved.

The optional fixed-root configuration support was added while the broader-root prototype was running. Its configuration remains unchanged and receives the original behavior because the new fields are absent. Its saved definition and a compatibility record preserve the previous code hashes. The two studies never share learned checkpoints; the primary study can copy only the identical raw-pixel cache and training normalization, with provenance and manifest validation.

The computer must remain awake for local training. Closing the lid or sleeping pauses computation; rerun the same command if the process exits. Checkpoint recovery preserves completed work. No detached startup service or automatic Windows restart task is installed.

## Folder map

```text
neural_tree_v2/
  README.md
  pyproject.toml
  requirements-lock.txt
  .gitignore
  configs/
    study.json
    tree-budget-study.json
  v2_tree/
    __init__.py
    __main__.py
    common.py          checkpoint, randomness, file-lock helpers
    data.py            original split reuse, pixel caching, normalization
    models.py          pixel MLP, node CNN, recursive correction tree
    train.py           masked node tasks, signed refits, exact resume
    study.py           controls, bounded fitting attempts, pruning, exports
    visualize.py       capacity plots and node response/attribution maps
  tests/
    test_v2.py
  scripts/
    run-study.ps1
    run-tree-budget-after-prototype.py
  runs/               generated, not source code
    smoke-verified/
    image-tree-v2/
      definition.json
      preserved-originals.json
      environment.json
      progress.json
      runner.lock
      cats_vs_dogs/
        pixels.pt
        selection.json
        <experiment>/
          metrics.json
          deployment.pt
          audit.pt
          node-histories.json
          class-<label>/
            <node>-base.pt
            <node>-correction.pt
            <node>-final.pt
      cifar10/        same organization
    tree-budget-v2/  primary study, same organization plus queue.lock
  results/
    image-tree-v2/
      README.md
      measurements.csv
      measurements.json
      <dataset>-architecture-comparison.png
      <dataset>-capacity.png
      <dataset>-capacity-observations.json
      <dataset>/
        node-observations.json
        <node>-responses.png
    tree-budget-v2/  primary figures and measurements
```

Generated paths appear as their stages complete. The lock file remains after completion; the operating system releases the lock automatically. Check `progress.json`, not the existence of that file, for status. The `complete` status means the requested stage finished; whether the training-fit target was met is reported separately.

Version 1 result files, reports, manifests, and upload archives are hashed before this study and verified unchanged at dataset completion. This project does not overwrite their PDF or submission package. Version 2's final report and upload package should be assembled after results and interpretations have been reviewed.
